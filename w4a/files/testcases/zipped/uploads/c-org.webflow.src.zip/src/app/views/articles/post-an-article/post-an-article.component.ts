import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-an-article',
  templateUrl: './post-an-article.component.html',
  styleUrls: ['./post-an-article.component.css']
})
export class PostAnArticleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
