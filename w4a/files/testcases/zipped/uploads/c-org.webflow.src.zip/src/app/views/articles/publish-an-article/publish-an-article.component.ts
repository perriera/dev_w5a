import { Component, OnInit } from '@angular/core';
import { Article } from '../../../models/Article.model';
import { ArticleService } from '../../../controls/article.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-publish-an-article',
  templateUrl: './publish-an-article.component.html',
  styleUrls: ['./publish-an-article.component.css']
})
export class PublishAnArticleComponent implements OnInit {

  article = new Article();
  showPublishButton = true;
  showConfirmButton = false;
  errorMessage = '';

  constructor(private articleService: ArticleService,
              private route: ActivatedRoute,
              private router: Router) {
  }

  ngOnInit() {

    this.errorMessage = '';

    this.route.params
      .subscribe(
        (params: Params) => {
          this.articleService.getPrivateArticle(params[ 'id' ])
            .subscribe(
              (article: Article) => this.article = article as Article,
              (error) => this.errorMessage = error.message
            );
        }
      );

  }

  onPublishButton() {
    this.showPublishButton = false;
    this.showConfirmButton = true;
  }

  onConfirmButton() {
    this.articleService.publishArticle(this.article)
      .subscribe(
        (article: Article) => {
          this.article = article as Article;
          this.router.navigate([ '/users_profile' ]);
        },
        (error) => this.errorMessage = error.message
      );
  }

  onCancelButton() {
    this.router.navigate([ '/users_profile' ]);
  }

}
