import { Component, OnInit } from '@angular/core';
import { ArticleService } from '../../../controls/article.service';
import { IArticle, IArticleDocument } from '../../../shared/IArticle.interface';
import { Cursor } from '../../../shared/Cursor.container';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: [ './profile.component.css' ]
})
export class ProfileComponent implements OnInit {

  errorMessage = '';


  constructor(private articleService: ArticleService,
              private router: Router) {
  }

  ngOnInit() {
  }

  onAdd() {
    this.router.navigate([ '/articles_submit_an_article' ]);
  }

}
