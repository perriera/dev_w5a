import { Component, OnInit } from '@angular/core';
import { ArticleService } from '../../../controls/article.service';
import { Router } from '@angular/router';
import { AuthService } from '../../../controls/auth.service';
import { Article } from '../../../models/Article.model';


@Component({
  selector: 'app-submit-an-article',
  templateUrl: './submit-an-article.component.html',
  styleUrls: [ './submit-an-article.component.css' ]
})
export class SubmitAnArticleComponent implements OnInit {

  constructor(private router: Router,
              private articleService: ArticleService,
              private authService: AuthService) {
  }

  ngOnInit() {
    this.articleService.articleSubmitted
      .subscribe(
        (article: Article) => {
          this.router.navigate([ '/articles_review_an_article', article._id ]);
        }
      );
  }

}
