import { IArticleDocument } from '../shared/IArticle.interface';
import { IUserDocument } from '../shared/IUser.interface';


export class Article implements IArticleDocument {

  constructor(public _id = '',
              public posted: Date = new Date(),
              public author = '',
              public title = '',
              public summary = '',
              public text = '',
              public published = false,
              public user: IUserDocument = null) {
  }

}
