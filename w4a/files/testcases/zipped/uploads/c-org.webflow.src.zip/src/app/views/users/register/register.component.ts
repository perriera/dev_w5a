import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../../controls/auth.service';
import { Router } from '@angular/router';
import { IUserDocument } from '../../../shared/IUser.interface';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: [ './register.component.css' ]
})
export class RegisterComponent implements OnInit {

  errorMessage = '';
  helpMessage = '';

  constructor(private router: Router,
              private authService: AuthService) {
  }

  ngOnInit() {
    this.errorMessage = '';
    this.helpMessage = '';
  }

  onSignup(form: NgForm) {
    this.authService.signupUser(form.value)
      .subscribe(
        (user: IUserDocument) => {
          console.log(user);
          form.reset();
          this.router.navigateByUrl('/');
        }, (error) => {
          this.errorMessage = error.message;
        }
      );
  }

}
