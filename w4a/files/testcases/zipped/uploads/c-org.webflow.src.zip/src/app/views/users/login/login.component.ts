import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../../controls/auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: [ './login.component.css' ]
})
export class LoginComponent implements OnInit {

  errorMessage = '';
  helpMessage = '';

  constructor(private router: Router,
              private authService: AuthService) {
  }

  validateEmail(email) {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
  }

  ngOnInit() {
    this.errorMessage = '';
    this.helpMessage = '';
  }

  onSignin(form: NgForm) {
    const query = form.value.emailorusername;
    if (this.validateEmail(query)) {
      form.value.email = query;
    } else {
      form.value.username = query;
    }
    this.authService.signinUser(form.value)
      .subscribe(
        () => {
          form.reset();
          this.router.navigateByUrl('/');
        }, (error) => {
          this.errorMessage = 'Cannot connect to the server!';
          console.log(error);
        }
      );
  }

  onMe() {
    this.authService.me()
      .subscribe(
        () => {
          this.router.navigateByUrl('/');
        }, (error) => {
          this.errorMessage = error.message;
        }
      );
  }

}
