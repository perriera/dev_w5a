import { Component, Input, OnInit } from '@angular/core';
import { Article } from '../../models/Article.model';
import { ArticleService } from '../../controls/article.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-article-detail',
  templateUrl: './article-detail.component.html',
  styleUrls: [ './article-detail.component.css' ]
})
export class ArticleDetailComponent implements OnInit {

  @Input() article = new Article();

  id: string;
  errorMessage = '';

  constructor(private articleService: ArticleService,
              private route: ActivatedRoute,
              private router: Router) {
  }

  ngOnInit() {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params[ 'id' ];
          this.articleService.getPublicArticle(this.id)
            .subscribe(
              (article: Article) => {
                this.article = article as Article;
                console.log(this.article);
              },
              (error) => {
                this.errorMessage = error.message;
                console.log(error);
              }
            );
        }
      );

  }

}
