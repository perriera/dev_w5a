import { Component, OnInit } from '@angular/core';

import { AuthService } from '../../controls/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: [ './home.component.css' ]
})
export class HomeComponent implements OnInit {

  errorMessage = '';


  constructor(private router: Router,
              private authService: AuthService) {
  }

  ngOnInit() {
  }

}
