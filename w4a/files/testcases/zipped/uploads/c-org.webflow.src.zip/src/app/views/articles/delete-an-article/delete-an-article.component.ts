import { Component, OnInit } from '@angular/core';
import { Article } from '../../../models/Article.model';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ArticleService } from '../../../controls/article.service';

@Component({
  selector: 'app-delete-an-article',
  templateUrl: './delete-an-article.component.html',
  styleUrls: [ './delete-an-article.component.css' ]
})
export class DeleteAnArticleComponent implements OnInit {

  article = new Article();
  showDeleteButton = true;
  showConfirmButton = false;
  errorMessage = '';

  constructor(private articleService: ArticleService,
              private route: ActivatedRoute,
              private router: Router) {
  }

  ngOnInit() {

    this.errorMessage = '';

    this.route.params
      .subscribe(
        (params: Params) => {
          this.articleService.getPrivateArticle(params[ 'id' ])
            .subscribe(
              (article: Article) => this.article = article as Article,
              (error) => this.errorMessage = error.message
            );
        }
      );

  }

  onDeleteButton() {
    this.showDeleteButton = false;
    this.showConfirmButton = true;
  }

  onConfirmButton() {
    this.articleService.deleteArticle(this.article)
      .subscribe(
        (article: Article) => {
          this.article = article as Article;
          this.router.navigate([ '/users_profile' ]);
        },
        (error) => this.errorMessage = error.message
      );
  }

  onCancelButton() {
    this.router.navigate([ '/users_profile' ]);
  }

}
