import { Component, OnInit } from '@angular/core';
import { AuthService } from './controls/auth.service';
import { AuthPingService } from './controls/auth-ping.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit {

  constructor(private authService: AuthService,
              private authPingService: AuthPingService) {
  }

  ngOnInit() {
    this.authPingService.monitorAccess();
  }

  onMouseOver() {
    this.authPingService.monitorPing();
  }

}
