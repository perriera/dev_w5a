/**
 * Created by perry on 2017-07-28.
 */

export class ServerConstants {

    public static base = 'http://localhost:3000';

}

export class ServerMounts {

    public static root = '/';
    public static api_auth = '/api/auth';
    public static api_article = '/api/article';
    public static api_articles = '/api/articles';

}

export class ArticleMounts extends ServerMounts {

    public static _create = '/create';
    public static _update = '/update';
    public static _delete = '/delete';
    public static _getPrivate = '/getPrivate';
    public static _getPublic = '/getPublic';
    public static _updateText = '/updateText';
    public static _publishText = '/publishText';
    public static _unPublishText = '/unPublishText';
    public static _ping = '/ping';

    public static create = ServerMounts.api_article + ArticleMounts._create;
    public static update = ServerMounts.api_article + ArticleMounts._update;
    public static delete = ServerMounts.api_article + ArticleMounts._delete;
    public static getPrivate = ServerMounts.api_article + ArticleMounts._getPrivate ;
    public static getPublic = ServerMounts.api_article + ArticleMounts._getPublic;
    public static updateText = ServerMounts.api_article + ArticleMounts._updateText;
    public static publishText = ServerMounts.api_article + ArticleMounts._publishText;
    public static unPublishText = ServerMounts.api_article + ArticleMounts._unPublishText;
    public static ping = ServerMounts.api_article + ArticleMounts._ping;

}

export class ArticlesMounts extends ServerMounts {

    public static _pingPrivate = '/pingPrivate';
    public static _pingPublic = '/pingPublic';
    public static _createTestData = '/createTestData';
    public static _getPublicCursor = '/getPublicCursor';
    public static _getPrivateCursor = '/getPrivateCursor';
    public static _getPublic = '/getPublic';
    public static _getPrivate = '/getPrivate';
    public static _resetDatabase = '/resetDatabase';

    public static pingPrivate = ServerMounts.api_articles + ArticlesMounts._pingPrivate;
    public static pingPublic = ServerMounts.api_articles + ArticlesMounts._pingPublic;
    public static createTestData = ServerMounts.api_articles + ArticlesMounts._createTestData;
    public static getPublicCursor = ServerMounts.api_articles + ArticlesMounts._getPublicCursor;
    public static getPrivateCursor = ServerMounts.api_articles + ArticlesMounts._getPrivateCursor;
    public static getPublic = ServerMounts.api_articles + ArticlesMounts._getPublic;
    public static getPrivate = ServerMounts.api_articles + ArticlesMounts._getPrivate;
    public static resetDatabase = ServerMounts.api_articles + ArticlesMounts._resetDatabase;

}

export class AuthMounts extends ServerMounts {

    public static _signUp = '/signUp';
    public static _signIn = '/signIn';
    public static _me = '/me';
    public static _stuff = '/stuff';
    public static _signOut = '/signOut';
    public static _testPost = '/testPost';
    public static _ping = '/ping';
    public static _checkAuthentication = '/checkAuthentication';

    public static signUp = ServerMounts.api_auth + AuthMounts._signUp;
    public static signIn = ServerMounts.api_auth + AuthMounts._signIn;
    public static me = ServerMounts.api_auth + AuthMounts._me;
    public static stuff = ServerMounts.api_auth + AuthMounts._stuff;
    public static signOut = ServerMounts.api_auth + AuthMounts._signOut;
    public static testPost = ServerMounts.api_auth + AuthMounts._testPost;
    public static ping = ServerMounts.api_auth + AuthMounts._ping;
    public static checkAuthentication = ServerMounts.api_auth + AuthMounts._checkAuthentication;

}

