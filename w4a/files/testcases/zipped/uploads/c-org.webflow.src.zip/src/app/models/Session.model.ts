import { User } from './User.model';
import { ISessionDocument } from '../shared/ISession.interface';


export class Session implements ISessionDocument {

  sid: string;
  expires: number;
  _id: string;

  constructor(
              public user: User,
              public token: string,
              public loggedIn: boolean) {
  }

}
