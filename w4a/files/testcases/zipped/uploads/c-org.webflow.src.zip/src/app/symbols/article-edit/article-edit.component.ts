import { Component, Input, OnInit } from '@angular/core';
import { Article } from '../../models/Article.model';
import { ArticleService } from '../../controls/article.service';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AuthService } from '../../controls/auth.service';

@Component({
  selector: 'app-article-edit',
  templateUrl: './article-edit.component.html',
  styleUrls: [ './article-edit.component.css' ]
})
export class ArticleEditComponent implements OnInit {

  @Input() article: Article = new Article();
  @Input() editMode = true;

  errorMessage = '';

  constructor(private router: Router,
              private route: ActivatedRoute,
              private articleService: ArticleService,
              private authService: AuthService) {
  }

  ngOnInit() {

    this.route.params
      .subscribe(
        (params: Params) => {
          const id = params[ 'id' ];
          this.articleService.getPrivateArticle(id)
            .subscribe(
              (article: Article) => this.article = article as Article,
              (error) => this.errorMessage = error.message
            );
        }
      );

  }

  onSubmit() {

    if (this.editMode) {
      this.articleService.updateArticle(this.article)
        .subscribe(
          (response: Article) => {
            this.article = response as Article;
            this.articleService.articleSubmitted.next(this.article);
          },
          (error) => this.errorMessage = error.message
        );
    } else {
      this.articleService.addArticle(this.article)
        .subscribe(
          (response: Article) => {
            this.article = response as Article;
            this.articleService.articleSubmitted.next(this.article);
          },
          (error) => this.errorMessage = error.message
        );
    }

  }

}
