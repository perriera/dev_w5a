import { Component, Input, OnInit } from '@angular/core';
import { ServerConstants, UploadMounts } from '../../shared/Server.mounts';
import { DropZoneFileUploader } from '../drop-zone-box/DropZoneFileUploader';
import { DownloadService } from '../../services/download.service';
import { FileItem } from 'ng2-file-upload';
import { IUploadStatus } from '../../shared/IUploadStatus';
import * as FileSaver from 'file-saver';
import { DropZoneService } from '../../services/DropZone.service';
import { AuthService } from '../../services/auth.service';
import { IUsageInterface } from '../../shared/IUsage.interface';
import { UsageService } from '../../services/usage.service';

@Component({
  selector: 'app-drop-zone-control',
  templateUrl: './drop-zone-control.component.html',
  styleUrls: [ './drop-zone-control.component.css' ]
})
export class DropZoneControlComponent implements OnInit {

  @Input() uploader: DropZoneFileUploader = new DropZoneFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

  @Input() control = 'Command';

  clearEnabled = false;
  commandEnabled = false;
  downloadEnabled = false;

  interval = null;
  filename = '';

  quota = false;
  errorMessage = '';

  constructor(private dropZoneService: DropZoneService,
              private authService: AuthService,
              private usageService: UsageService,
              private downloadService: DownloadService) {
  }

  ngOnInit() {
    this.uploader.afterAddingFile
      .subscribe((fileItem: FileItem) => {
        this.checkStatus();
      });
    this.checkUsage();
  }

  checkStatus() {
    this.clearEnabled = true;
    this.commandEnabled = this.uploader.isReady();
    this.checkUsage();
  }

  checkUsage() {
    this.usageService.getUsage()
      .subscribe(
        (usage: IUsageInterface) => {
          this.quota = usage.quota;
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  onClearButton() {
    this.uploader.doClear();
    this.clearEnabled = false;
    this.commandEnabled = false;
    this.downloadEnabled = false;
    clearInterval(this.interval);
    this.dropZoneService.onClearButton.next();
  }

  onCommandButton() {
    const token = this.authService.getToken();
    this.uploader.doUpload(token);
    this.doMonitor();
    this.commandEnabled = false;
  }

  doMonitor() {
    this.interval = setInterval(() => {
      this.downloadService.readyQuery(this.uploader.getUploadFilename())
        .subscribe(
          (response: IUploadStatus) => {
            if (response.exception) {
              clearInterval(this.interval);
              this.dropZoneService.setStatus.next(response.exceptionMsg);
            } else {
              this.downloadEnabled = response.downloadsFileExist && !response.uploadsFileExist;
              if (this.downloadEnabled) {
                clearInterval(this.interval);
                this.dropZoneService.setStatus.next('Ready for download!');
                this.filename = response.filename;
              } else {
                if (response.percentage === 0) {
                  this.dropZoneService.setStatus.next('One moment please ... ');
                } else {
                  this.dropZoneService.setStatus.next(response.percentage + ' %');
                }
              }
            }
          }, (error) => {
            console.log(error);
          }
        );
    }, 1000);
  }

  onDownloadButton() {
    this.doDownload();
    console.log('onDownloadButton called');
  }

  doDownload() {
    this.downloadService.retrieve(this.filename)
      .subscribe(
        (response) => {
          FileSaver.saveAs(response, this.uploader.getFreeFormName());
          this.onClearButton();
          this.doBump();
          this.dropZoneService.downloadedOk.next(this.filename);
        }, (error) => {
          console.log(error);
        }
      );
  }

  doBump() {
    this.usageService.bump()
      .subscribe(
        (usage: IUsageInterface) => {
          console.log(usage);
        }, (error) => {
          console.log(error);
        }
      );
  }

}
