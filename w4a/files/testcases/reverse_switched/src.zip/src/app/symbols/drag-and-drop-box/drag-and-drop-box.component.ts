import { Component, Input, OnInit } from '@angular/core';
import { ServerConstants, UploadMounts } from '../../shared/Server.mounts';
import { MyFileUploader } from './MyFileUpLoader';
import { FileItem, FileUploader } from 'ng2-file-upload';
import { DownloadService } from '../../services/download.service';
import { Router } from '@angular/router';
import * as FileSaver from 'file-saver';


@Component({
  selector: 'app-drag-and-drop-box',
  templateUrl: './drag-and-drop-box.component.html',
  styleUrls: [ './drag-and-drop-box.component.css' ]
})
export class DragAndDropBoxComponent implements OnInit {

  @Input() uploader: MyFileUploader = new MyFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

  @Input() state = 'Add zip to Forward Engineer here';
  @Input() status = '(required)';
  @Input() filename = 'Your (project).webflow.zip';
  @Input() command = 'Forward Engineer';

  _state = this.state;
  _status = this.status;
  _filename = this.filename;
  clearEnabled = false;
  commandEnabled = false;
  downloadEnabled = false;
  uploading = false;
  downloaded = false;
  downloading = false;
  processing = false;
  readyForDownload = false;
  percentage = 0;
  interval = null;

  constructor(private router: Router,
              private downloadService: DownloadService) {
  }

  ngOnInit() {
    this._state = this.state;
    this._status = this.status;
    this._filename = this.filename;
    this.uploader.afterAddingFile
      .subscribe((fileItem: FileItem) => {
        this.clearEnabled = true;
        this.commandEnabled = true;
        this.filename = fileItem.file.name;
      });
    this.uploader.clearAll
      .subscribe((fileItem: FileItem) => {
        this.onClear();
      });
  }

  onCommand() {
    this.uploader.uploadAll();
  }

  doClear() {
    this.uploader.doClear();
    this.onClear();
    clearInterval(this.interval);
  }

  onClear() {
    this.clearEnabled = false;
    this.commandEnabled = false;
    this.downloadEnabled = false;
    this.processing = false;
    this.readyForDownload = false;
    this.downloading = false;
    this.downloaded = false;
    this.percentage = 0;
    this.state = this._state;
    this.status = this._status;
    this.filename = this._filename;
  }

  doUpload() {
    this.percentage = 0;
    this.uploading = true;
    this.commandEnabled = false;
    this.uploader.doUpload();
    this.doMonitor();
    this.doSetStatus();
  }

  doSetStatus() {
    if ( this.uploading ) {
      this.status = 'Uploading ...';
    }
    if ( this.processing ) {
      this.status = 'Processing ' + this.percentage + '% ...';
    }
    if ( this.downloading ) {
      this.status = 'Downloading ...';
    }
    if ( this.readyForDownload ) {
      this.status = 'Ready for download';
    }
  }

  doMonitor() {
    this.interval = setInterval(() => {
      this.downloadService.readyQuery(this.filename)
        .subscribe(
          (response) => {
            // this.status1 = ( response.fileExist ? ' Ready for download ' : ' Processing ... ');
            this.uploading = !response.uploadsFileExist;
            this.processing = !response.downloadsFileExist && response.uploadsFileExist;
            this.readyForDownload = response.downloadsFileExist && !response.uploadsFileExist;
            if (response.downloadsFileExist && !response.uploadsFileExist) {
              this.downloadEnabled = true;
              clearInterval(this.interval);
            }
            if ( !this.readyForDownload ) {
              this.percentage = response.percentage;
            }
            this.doSetStatus();
            if ( response.exception ) {
              this.status = response.exceptionMsg;
              this.state = 'Is your account in good standing?'
              clearInterval(this.interval);
            }
            console.log(response);
          }, (error) => {
            console.log(error);
          }
        );
    }, 1000);
  }

  doDownload() {
    this.downloading = true;
    this.downloadService.retrieve(this.filename)
      .subscribe(
        (response) => {
          this.downloading = false;
          FileSaver.saveAs(response, this.filename);
          this.downloaded = true;
          this.doClear();
        }, (error) => {
          console.log(error);
        }
      );
  }

}
