"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ng2_file_upload_1 = require('ng2-file-upload');
var Subject_1 = require('rxjs/Subject');
/**
 * Created by perry on 2017-08-02.
 */
var MyFileUploader = (function (_super) {
    __extends(MyFileUploader, _super);
    function MyFileUploader(params) {
        _super.call(this, params);
        this.afterAddingFile = new Subject_1.Subject();
        this.completeAll = new Subject_1.Subject();
        this.clearAll = new Subject_1.Subject();
        this.uploadQueue = new Subject_1.Subject();
    }
    MyFileUploader.prototype.onCompleteAll = function () {
        this.completeAll.next();
    };
    MyFileUploader.prototype.onAfterAddingFile = function (fileItem) {
        this.afterAddingFile.next(fileItem);
    };
    MyFileUploader.prototype.onBeforeUploadItem = function (fileItem) {
        var token = 'F-6B7A2B1';
        fileItem.file.name = token + '_' + fileItem.file.name;
        return fileItem;
    };
    MyFileUploader.prototype.doClear = function () {
        this.clearQueue();
        this.clearAll.next();
    };
    MyFileUploader.prototype.doUpload = function () {
        this.uploadQueue.next(this);
    };
    return MyFileUploader;
}(ng2_file_upload_1.FileUploader));
exports.MyFileUploader = MyFileUploader;
//# sourceMappingURL=MyFileUpLoader.js.map