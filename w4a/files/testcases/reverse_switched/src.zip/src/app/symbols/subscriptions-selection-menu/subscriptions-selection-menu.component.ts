import { Component, OnInit } from '@angular/core';
import { IBillingPlanDocument } from '../../shared/IBillingPlan.interface';
import { Cursor } from '../../shared/Cursor.container';
import { PayPalService } from '../../services/paypal.service';
import { Router } from '@angular/router';
import { Http, RequestOptions, Response, Headers, URLSearchParams } from '@angular/http';

@Component({
  selector: 'app-subscriptions-selection-menu',
  templateUrl: './subscriptions-selection-menu.component.html',
  styleUrls: [ './subscriptions-selection-menu.component.css' ]
})
export class SubscriptionsSelectionMenuComponent implements OnInit {

  status: string;
  errorMessage: string;
  plans: Cursor<IBillingPlanDocument>;

  constructor(private router: Router,
              private payPalService: PayPalService) {
    this.plans = new Cursor<IBillingPlanDocument>();
  }

  ngOnInit() {
    this.updateListing();
    this.payPalService.billingPlansUpdated
      .subscribe(() => {
          this.updateListing();
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  updateListing() {
    this.payPalService.queryPlans(this.plans)
      .subscribe(
        (response: Cursor<IBillingPlanDocument>) => {
          this.plans = response as Cursor<IBillingPlanDocument>;
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  onSelect(billingPlan: IBillingPlanDocument) {
    console.log(billingPlan.billingPlanId);
    this.status = 'Connecting to PayPal ... ';
    this.payPalService.createAgreement(billingPlan)
      .subscribe(
        (response: Response) => {
          this.status = '... one moment please!';
          window.location.href = response.url;
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

}

