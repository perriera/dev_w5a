import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Session } from '../../models/Session.model';
import { ProfileService } from '../../services/profile.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile-menu',
  templateUrl: './profile-menu.component.html',
  styleUrls: [ './profile-menu.component.css' ]
})
export class ProfileMenuComponent implements OnInit {

  showProfileMenu = false;
  hideMenu = false;
  showAdminMenu = false;

  constructor(private router: Router,
              private authService: AuthService,
              private profileService: ProfileService) {
  }

  ngOnInit() {
    console.log('hello');
    this.authService.loginActivated
      .subscribe((session: Session) => {
        console.log(session);
        this.showAdminMenu = session.user.email === 'perry.anderson@gmail.com';
        this.showProfileMenu = session.loggedIn;
      });
    this.profileService.toggleMenu
      .subscribe(() => {
        this.hideMenu = !this.hideMenu;
      });
  }

  onSignout() {
    this.hideMenu = !this.hideMenu;
    this.authService.signoutUser()
      .subscribe(
        () => {
          console.log('signed out');
          this.router.navigateByUrl('/');
        }, (error) => {
          console.log(error.message);
        }
      );
  }

}

