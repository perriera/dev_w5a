import { Component, Input, OnInit } from '@angular/core';
import { ServerConstants, UploadMounts } from '../../shared/Server.mounts';
import { SingleFileUploader } from './SingleFileUploader';
import { FileItem } from 'ng2-file-upload';
import { DownloadService } from '../../services/download.service';
import { IUploadStatus } from '../../shared/IUploadStatus';
import * as FileSaver from 'file-saver';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-drag-and-drop',
  templateUrl: './drag-and-drop.component.html',
  styleUrls: [ './drag-and-drop.component.css' ]
})
export class DragAndDropComponent implements OnInit {

  @Input() uploader: SingleFileUploader = new SingleFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

  @Input() state = 'Add zip to Forward Engineer here';
  @Input() status = '(required)';
  @Input() filename = 'Your (project).webflow.zip';
  @Input() command = 'Forward Engineer';
  @Input() maxSize = 10000;
  @Input() token = 'jack';

  _state = '';
  _status = '';
  _filename = '';

  size = 0;

  clearEnabled = false;
  commandEnabled = false;
  downloadEnabled = false;

  interval = null;

  constructor(private downloadService: DownloadService) {
  }

  ngOnInit() {
    this.setUpDefaults();
    this.uploader.setToken(this.token);
    this.uploader.afterAddingFile
      .subscribe((fileItem: FileItem) => {
        this.filename = fileItem.file.name;
        this.size = (fileItem.file.size / 1000);
        this.checkStatus();
      });
  }

  checkStatus() {
    this.status = this.size.toFixed(2) + 'k';
    this.clearEnabled = true;
    if (this.size > this.maxSize) {
      const maxMsg = (this.maxSize / 1000).toFixed(0) + ' MB';
      this.status = 'This file exceeds the maximum file size of ' + maxMsg;
      this.commandEnabled = false;
    } else {
      this.commandEnabled = true;
    }
  }

  onClearButton() {
    this.uploader.doClear();
    this.useDefaults();
    this.clearEnabled = false;
    this.commandEnabled = false;
    this.downloadEnabled = false;
    console.log('onClearButton called');
  }

  onCommandButton() {
    this.uploader.doUpload();
    this.doMonitor();
    this.commandEnabled = false;
    console.log('onCommandButton called');
  }

  onDownloadButton() {
    this.doDownload();
    console.log('onDownloadButton called');
  }

  setUpDefaults() {
    this._state = this.state;
    this._status = this.status;
    this._filename = this.filename;
  }

  useDefaults() {
    this.state = this._state;
    this.status = this._status;
    this.filename = this._filename;
  }

  doMonitor() {
    this.interval = setInterval(() => {
      this.downloadService.readyQuery(this.uploader.getUploadFilename())
        .subscribe(
          (response: IUploadStatus) => {
            this.downloadEnabled = response.downloadsFileExist && !response.uploadsFileExist;
            if (this.downloadEnabled) {
              clearInterval(this.interval);
              this.status = 'Ready for download!';
            } else {
              this.status = response.percentage + ' %';
            }
            console.log(response);
          }, (error) => {
            console.log(error);
          }
        );
    }, 1000);
  }


  doDownload() {
    this.downloadService.retrieve(this.uploader.getUploadFilename())
      .subscribe(
        (response) => {
          FileSaver.saveAs(response, this.filename);
          this.onClearButton();
        }, (error) => {
          console.log(error);
        }
      );
  }

}
