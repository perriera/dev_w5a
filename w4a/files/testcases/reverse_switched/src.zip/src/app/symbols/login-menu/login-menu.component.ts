import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { ProfileService } from '../../services/profile.service';

@Component({
  selector: 'app-login-menu',
  templateUrl: './login-menu.component.html',
  styleUrls: [ './login-menu.component.css' ]
})
export class LoginMenuComponent implements OnInit {

  constructor(private router: Router,
              private authService: AuthService,
              private profileService: ProfileService) {
  }

  ngOnInit() {
  }

  loggedIn() {
    return this.authService.isAuthenticated();
  }

  toggleProfileMenu() {
    this.profileService.toggleMenu.next();
  }

}

