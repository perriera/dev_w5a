/**
 * Created by perry on 2017-08-14.
 */

import { ServerConstants, UploadMounts } from '../../shared/Server.mounts';
import { Input } from '@angular/core';
import { SingleFileUploader } from './SingleFileUploader';


export class DualFileUploader {

  @Input() uploader1: SingleFileUploader = new SingleFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

  @Input() uploader2: SingleFileUploader = new SingleFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

}
