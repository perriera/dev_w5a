import { Component, OnInit } from '@angular/core';
import { IBillingPlanDocument } from '../../shared/IBillingPlan.interface';
import { Cursor } from '../../shared/Cursor.container';
import { PayPalService } from '../../services/paypal.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-subscription-plans-listing',
  templateUrl: './subscription-plans-listing.component.html',
  styleUrls: ['./subscription-plans-listing.component.css']
})
export class SubscriptionPlansListingComponent implements OnInit {

  status: string;
  errorMessage: string;
  plans: Cursor<IBillingPlanDocument>;

  constructor(private router: Router,
              private payPalService: PayPalService) {
    this.plans = new Cursor<IBillingPlanDocument>();
  }

  ngOnInit() {
    this.updateListing();
    this.payPalService.billingPlansUpdated
      .subscribe( () => {
          this.updateListing();
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  updateListing() {
    this.payPalService.queryPlans(this.plans)
      .subscribe(
        (response: Cursor<IBillingPlanDocument>) => {
          this.plans = response as Cursor<IBillingPlanDocument>;
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

}

