import { FileItem, FileUploader } from 'ng2-file-upload';
import { Subject } from 'rxjs/Subject';
/**
 * Created by perry on 2017-08-02.
 */


export class MyFileUploader extends FileUploader {

  afterAddingFile = new Subject();
  completeAll = new Subject();
  clearAll = new Subject();
  uploadQueue = new Subject();

  constructor(params) {
    super(params);
  }

  onCompleteAll() {
    this.completeAll.next();
  }

  onAfterAddingFile(fileItem: FileItem) {
    this.afterAddingFile.next(fileItem);
  }

  onBeforeUploadItem(fileItem: FileItem) {
    const token = 'F-6B7A2B1';
    fileItem.file.name = token + '_' + fileItem.file.name;
    return fileItem;
  }

  doClear() {
    this.clearQueue();
    this.clearAll.next();
  }

  doUpload() {
    this.uploadQueue.next(this);
  }

}
