import { Component, Input, OnInit } from '@angular/core';
import { ServerConstants, UploadMounts } from '../../shared/Server.mounts';
import { SingleFileUploader } from '../drag-and-drop/SingleFileUploader';
import { FileItem } from 'ng2-file-upload';
import { DropZoneFileUploader } from './DropZoneFileUploader';
import { DropZoneService } from '../../services/DropZone.service';
import { IUsageInterface } from '../../shared/IUsage.interface';
import { UsageService } from '../../services/usage.service';

@Component({
  selector: 'app-drop-zone-box',
  templateUrl: './drop-zone-box.component.html',
  styleUrls: [ './drop-zone-box.component.css' ]
})
export class DropZoneBoxComponent implements OnInit {

  @Input() uploader: DropZoneFileUploader = new DropZoneFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

  @Input() state = '*state*';
  @Input() status = '*status*';
  @Input() filename = '*filename*';
  @Input() command = 'Forward Engineer';
  @Input() maxSize = 20000;

  _state = 'x';
  _status = 'y';
  _filename = 'z';

  quota = false;
  errorMessage = '';
  quotaStatus = '';

  constructor(private dropZoneService: DropZoneService,
              private usageService: UsageService) {

    /* code for file size monitoring
    https://github.com/valor-software/ng2-file-upload/blob/development/demo/src/app/components/file-upload/simple-demo.html
     */
  }

  ngOnInit() {
    this.setUpDefaults();
    this.uploader.setMaxSize(this.maxSize);
    this.uploader.afterAddingFile
      .subscribe((fileItem: FileItem) => {
        this.filename = fileItem.file.name;
        this.checkStatus();
      });
    this.dropZoneService.onClearButton
      .subscribe(() => {
        this.useDefaults();
        this.checkUsage();
      });
    this.dropZoneService.setStatus
      .subscribe((message: string) => {
        this.status = message;
      });
    this.dropZoneService.downloadedOk
      .subscribe((message: string) => {
        this.checkUsage();
      });
    this.checkUsage();
  }

  checkUsage() {
    this.usageService.getUsage()
      .subscribe(
        (usage: IUsageInterface) => {
          this.quota = usage.quota;
          this.doQuota(usage);
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  checkStatus() {
    this.status = this.uploader.getSizeMsg();
    this.checkUsage();
  }

  setUpDefaults() {
    this._state = this.state;
    this._status = this.status;
    this._filename = this.filename;
  }

  useDefaults() {
    this.state = this._state;
    this.status = this._status;
    this.filename = this._filename;
  }

  doQuota(usage: IUsageInterface) {
    if (this.quota) {
      if (usage.subscribed) {
        this.status = 'You have exceeded your quota for the hour';
        this.quotaStatus = 'Please consider upgrading to a larger package.';
      } else {
        this.status = 'You have exceeded your quota for the day.';
        this.quotaStatus = 'Please consider subscribing to a paid membership.';
      }
    } else {
      if (usage.subscribed) {
        this.quotaStatus = 'You have used ' + usage.usages + ' of ' + usage.limit + ' for the hour.';
      } else {
        this.quotaStatus = 'You have used ' + usage.usages + ' of ' + usage.limit + ' for the day.';
      }
    }

  }


}
