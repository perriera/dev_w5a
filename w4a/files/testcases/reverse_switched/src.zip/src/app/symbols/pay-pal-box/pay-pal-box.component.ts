import { Component, OnInit } from '@angular/core';
import * as paypal from 'paypal-rest-sdk';
import { NgForm } from '@angular/forms';
import { Payment } from 'paypal-rest-sdk';

@Component({
  selector: 'app-pay-pal-box',
  templateUrl: './pay-pal-box.component.html',
  styleUrls: [ './pay-pal-box.component.css' ]
})
export class PayPalBoxComponent implements OnInit {

  title = 'Webflow to Angular 2 Subscriptions';

  constructor() {
  }

  ngOnInit() {
  }

  onSubmit(form: NgForm) {

  }

}

