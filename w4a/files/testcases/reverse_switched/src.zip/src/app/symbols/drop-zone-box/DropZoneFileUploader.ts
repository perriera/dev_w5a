import { FileItem, FileUploader } from 'ng2-file-upload';
import { Subject } from 'rxjs/Subject';
import { Token } from '../../shared/Token';
/**
 * Created by perry on 2017-08-13.
 */

export class DropZoneFileUploader extends FileUploader {

  afterAddingFile = new Subject();

  token = '[token-not-set]';
  originalWebflowFilename = '';
  uploadFilename = '';
  size = 0;
  maxSize = 10000;

  constructor(params) {
    super(params);
  }

  onAfterAddingFile(fileItem: FileItem) {
    this.originalWebflowFilename = fileItem.file.name;
    while (this.queue.length > 1) {
      this.removeFromQueue(this.queue[ 0 ]);
    }
    this.size = fileItem.file.size / 1000;
    this.afterAddingFile.next(fileItem);
    for (let i = 0; i < this.queue.length; i++) {
      console.log(this.queue[ i ].file.name);
    }
  }

  onBeforeUploadItem(fileItem: FileItem) {
    // this.originalWebflowFilename = fileItem.file.name;
    this.uploadFilename = this.token + '_' + fileItem.file.name;
    fileItem.file.name = this.uploadFilename;
    return fileItem;
  }

  getFreeFormName() {
      return Token.getDownloadFilename(this.originalWebflowFilename);
  }

  isTooBig() {
    return this.size > this.maxSize;
  }

  isLoaded() {
    return this.size > 0;
  }

  isReady() {
    return this.isLoaded() && !this.isTooBig();
  }

  setToken(token: string) {
    this.token = token;
  }

  setMaxSize(maxSize:number) {
    this.maxSize = maxSize;
  }

  getSizeMsg() {
    let msg = this.size.toFixed(0) + 'k';
    if (this.size > this.maxSize) {
      const maxMsg = (this.maxSize / 1000).toFixed(0) + ' MB';
      msg = 'Maximum file size is ' + maxMsg;
    }
    return msg;
  }

  getUploadFilename() {
    return this.uploadFilename;
  }

  doClear() {
    this.originalWebflowFilename = '';
    this.uploadFilename = '';
    this.clearQueue();
  }

  doUpload(token: string) {
    this.authToken = token;
    this.uploadAll();
  }

}
