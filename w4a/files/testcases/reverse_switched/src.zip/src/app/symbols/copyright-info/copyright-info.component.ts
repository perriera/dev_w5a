import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-copyright-info',
  templateUrl: './copyright-info.component.html',
  styleUrls: ['./copyright-info.component.css']
})
export class CopyrightInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

