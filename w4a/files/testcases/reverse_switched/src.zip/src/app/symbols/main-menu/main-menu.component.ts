import { Component, OnInit } from '@angular/core';
import { UsageService } from '../../services/usage.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { IUsageInterface } from '../../shared/IUsage.interface';

@Component({
  selector: 'app-main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: [ './main-menu.component.css' ]
})
export class MainMenuComponent implements OnInit {

  errorMessage = '';
  operational = false;

  constructor(private router: Router,
              private authService: AuthService,
              private usageService: UsageService) {
  }

  ngOnInit() {
    this.authService.loginActivated
      .subscribe(() => {
        this.checkStatus();
      });
    this.usageService.usageState
      .subscribe(
        (usage: IUsageInterface) => {
          this.operational = true; // !usage.quota;
        }, (error) => {
          this.errorMessage = 'Cannot connect to the server!';
          console.log(error);
        }
      );

  }

  checkStatus() {
    this.operational = !this.usageService.exceededLimit();
  }

}
