import { FileItem, FileUploader } from 'ng2-file-upload';
import { Subject } from 'rxjs/Subject';
/**
 * Created by perry on 2017-08-13.
 */

export class SingleFileUploader extends FileUploader {

  afterAddingFile = new Subject();

  token = '[token-not-set]';
  uploadFilename = '';

  constructor(params) {
    super(params);
  }

  setToken(token: string) {
    this.token = token;
  }

  getUploadFilename() {
    return this.uploadFilename;
  }

  onAfterAddingFile(fileItem: FileItem) {
    while (this.queue.length > 1) {
      this.removeFromQueue(this.queue[ 0 ]);
    }
    this.afterAddingFile.next(fileItem);
    for (let i = 0; i < this.queue.length; i++) {
      console.log(this.queue[ i ].file.name);
    }
  }

  onBeforeUploadItem(fileItem: FileItem) {
    this.uploadFilename = this.token + '_' + fileItem.file.name;
    fileItem.file.name = this.uploadFilename;
    return fileItem;
  }

  doClear() {
    this.clearQueue();
  }

  doUpload() {
    this.uploadAll();
  }

}
