import { Component, Input, OnInit } from '@angular/core';
import { ServerConstants, UploadMounts } from '../../../shared/Server.mounts';
import { DropZoneFileUploader } from '../../../symbols/drop-zone-box/DropZoneFileUploader';
import { FileItem } from 'ng2-file-upload';
import { IUploadStatus } from '../../../shared/IUploadStatus';
import { DownloadService } from '../../../services/download.service';
import * as FileSaver from 'file-saver';
import { DropZoneService } from '../../../services/DropZone.service';
import { AuthService } from '../../../services/auth.service';
import { IUsageInterface } from '../../../shared/IUsage.interface';
import { UsageService } from '../../../services/usage.service';

@Component({
  selector: 'app-reverse',
  templateUrl: './reverse.component.html',
  styleUrls: [ './reverse.component.css' ]
})
export class ReverseComponent implements OnInit {

  @Input() uploader1: DropZoneFileUploader = new DropZoneFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

  @Input() uploader2: DropZoneFileUploader = new DropZoneFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

  token = 'R-33453';

  clearEnabled = false;
  commandEnabled = false;
  downloadEnabled = false;

  interval = null;
  downloadFilename = '';
  filename = '';
  quota = false;
  errorMessage = '';

  constructor(private dropZoneService: DropZoneService,
              private authService: AuthService,
              private usageService: UsageService,
              private downloadService: DownloadService) {
  }

  ngOnInit() {
    this.uploader1.setToken(this.token);
    this.uploader2.setToken(this.token);
    this.uploader1.afterAddingFile
      .subscribe((fileItem: FileItem) => {
        this.checkStatus();
      });
    this.uploader2.afterAddingFile
      .subscribe((fileItem: FileItem) => {
        this.checkStatus();
      });
    this.checkUsage();
  }

  checkUsage() {
    this.usageService.getUsage()
      .subscribe(
        (usage: IUsageInterface) => {
          this.quota = usage.quota;
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  checkStatus() {
    this.clearEnabled = true;
    const test1 = this.uploader1.isReady();
    const test2 = this.uploader2.isReady();
    this.commandEnabled = test1 && test2;
    this.checkUsage();
  }

  onClearButton() {
    this.uploader1.doClear();
    this.uploader2.doClear();
    this.clearEnabled = false;
    this.commandEnabled = false;
    this.downloadEnabled = false;
    clearInterval(this.interval);
    this.dropZoneService.onClearButton.next();
    console.log('onClearButton called');
  }

  onCommandButton() {
    const test1 = this.uploader1.originalWebflowFilename;
    const test2 = this.uploader2.originalWebflowFilename;
    if ( test1 ===  test2 ) {
      this.dropZoneService.setStatus.next('You put the same zip file in both boxes by mistake.');
      this.commandEnabled = false;
    } else {
      const token = this.authService.getToken();
      this.uploader1.doUpload(token);
      this.uploader2.doUpload(token);
      this.doMonitor();
      this.commandEnabled = false;
    }
    console.log('onCommandButton called');
  }

  doMonitor() {
    this.interval = setInterval(() => {
      this.downloadService.readyQuery(this.uploader1.getUploadFilename())
        .subscribe(
          (response: IUploadStatus) => {
            if ( response.exception ) {
              clearInterval(this.interval);
              this.dropZoneService.setStatus.next(response.exceptionMsg);
            } else {
              this.downloadEnabled = response.downloadsFileExist && !response.uploadsFileExist;
              if (this.downloadEnabled) {
                clearInterval(this.interval);
                this.dropZoneService.setStatus.next('Ready for download!');
                this.filename = response.filename;
              } else {
                if ( response.percentage === 0 ) {
                  this.dropZoneService.setStatus.next('One moment please ... ');
                } else {
                  this.dropZoneService.setStatus.next(response.percentage + ' %');
                }
              }
            }
            console.log(response);
          }, (error) => {
            console.log(error);
          }
        );
    }, 1000);
  }

  onDownloadButton() {
    this.doDownload();
    console.log('onDownloadButton called');
  }

  doDownload() {
    this.downloadService.retrieve(this.filename)
      .subscribe(
        (response) => {
          FileSaver.saveAs(response, this.uploader1.getFreeFormName());
          this.onClearButton();
          this.doBump();
          this.dropZoneService.downloadedOk.next(this.filename);
        }, (error) => {
          console.log(error);
        }
      );
  }

  doBump() {
    this.usageService.bump()
      .subscribe(
        (usage: IUsageInterface) => {
          console.log(usage);
        }, (error) => {
          console.log(error);
        }
      );
  }

}
