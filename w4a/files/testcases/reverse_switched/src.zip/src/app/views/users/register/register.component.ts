import { Component, OnInit } from '@angular/core';
import { IUserDocument } from '../../../shared/IUser.interface';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: [ './register.component.css' ]
})
export class RegisterComponent implements OnInit {

  errorMessage = '';
  helpMessage = '';

  constructor(private router: Router,
              private authService: AuthService) {
  }

  ngOnInit() {
    this.errorMessage = '';
    this.helpMessage = '';
  }

  onSignup(form: NgForm) {
    console.log(form.value);
    this.authService.signupUser(form.value)
      .subscribe(
        (user: IUserDocument) => {
          console.log(user);
          form.reset();
          this.router.navigateByUrl('/');
        }, (error) => {
          this.errorMessage = error.message;
        }
      );
  }

}
