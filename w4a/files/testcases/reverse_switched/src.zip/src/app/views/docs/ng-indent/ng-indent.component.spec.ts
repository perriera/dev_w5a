/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { NgIndentComponent } from './ng-indent.component';

describe('NgIndentComponent', () => {
  let component: NgIndentComponent;
  let fixture: ComponentFixture<NgIndentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgIndentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgIndentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

