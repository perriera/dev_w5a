import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-id',
  templateUrl: './ng-id.component.html',
  styleUrls: ['./ng-id.component.css']
})
export class NgIdComponent implements OnInit {

  contentToShow = 1;

  constructor() { }

  ngOnInit() {
  }

}

