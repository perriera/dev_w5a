import { Component, OnInit } from '@angular/core';
import { UsageService } from '../../../services/usage.service';
import { PayPalService } from '../../../services/paypal.service';
import { Router } from '@angular/router';
import { IUsageInterface } from '../../../shared/IUsage.interface';

@Component({
  selector: 'app-are-you-sure',
  templateUrl: './are-you-sure.component.html',
  styleUrls: [ './are-you-sure.component.css' ]
})
export class AreYouSureComponent implements OnInit {

  status: string;
  errorMessage: string;
  subscribed = true;

  constructor(private router: Router,
              private payPalService: PayPalService,
              private usageService: UsageService) {
  }

  ngOnInit() {
    this.usageService.getUsage()
      .subscribe(
        (usage: IUsageInterface) => {
          console.log(usage);
          this.subscribed = usage.subscribed;
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  onCancelAgreement() {
    // this.payPalService.cancelAgreement()
    //   .subscribe(
    //     (usage: IUsageInterface) => {
    //       console.log(usage);
    //       this.subscribed = false;
    //     }, (error) => {
    //       this.errorMessage = error.message;
    //       console.log(error);
    //     }
    //   );
  }

}

