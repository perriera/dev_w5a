import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { UsageService } from '../../services/usage.service';
import { IUsageInterface } from '../../shared/IUsage.interface';
import { Session } from '../../models/Session.model';
import { ServerConstants } from '../../shared/Server.mounts';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: [ './home.component.css' ]
})
export class HomeComponent implements OnInit {

  loggedIn = false;
  errorMessage = '';

  constructor(private router: Router,
              private usageService: UsageService,
              private authService: AuthService) {
  }

  ngOnInit() {
    this.handlePayPalResults();
    this.handleLoginState();

    if (ServerConstants.live) {
      console.log(window.location.href);
      console.log(ServerConstants.client);
      if (!window.location.href.includes(ServerConstants.client)) {
        window.location.href = ServerConstants.client;
      }
    }

  }

  checkStatus() {
    return this.loggedIn;
  }

  handlePayPalResults() {
    const test1 = this.authService.isAuthenticated();
    this.authService.restoreToken();
    const test2 = this.authService.isAuthenticated();
    if (!test1 && test2) {
      this.usageService.getUsage()
        .subscribe(
          (usage: IUsageInterface) => {
            console.log(usage);
            if (usage.subscribed) {
              this.router.navigateByUrl('/subscriptions_thank_you');
            } else {
              this.router.navigateByUrl('/subscriptions_cancel_checkout');
            }
          }, (error) => {
            this.errorMessage = 'Cannot connect to the server!';
            console.log(error);
          }
        );
    }
  }

  handleLoginState() {
    this.authService.loginActivated
      .subscribe((session: Session) => {
        this.loggedIn = session.loggedIn;
      });
  }

}
