/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { NgIdComponent } from './ng-id.component';

describe('NgIdComponent', () => {
  let component: NgIdComponent;
  let fixture: ComponentFixture<NgIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

