import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-checkout',
  templateUrl: './cancel-checkout.component.html',
  styleUrls: ['./cancel-checkout.component.css']
})
export class CancelCheckoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

