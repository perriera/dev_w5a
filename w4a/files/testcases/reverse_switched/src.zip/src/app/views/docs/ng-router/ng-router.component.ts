import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-router',
  templateUrl: './ng-router.component.html',
  styleUrls: ['./ng-router.component.css']
})
export class NgRouterComponent implements OnInit {

  contentToShow = 1;

  constructor() { }

  ngOnInit() {
  }

}

