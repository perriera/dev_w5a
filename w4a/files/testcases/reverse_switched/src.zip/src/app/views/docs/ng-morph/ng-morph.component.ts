import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-morph',
  templateUrl: './ng-morph.component.html',
  styleUrls: ['./ng-morph.component.css']
})
export class NgMorphComponent implements OnInit {

  contentToShow = 1;

  constructor() { }

  ngOnInit() {
  }

}

