import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-to-cancel',
  templateUrl: './how-to-cancel.component.html',
  styleUrls: ['./how-to-cancel.component.css']
})
export class HowToCancelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

