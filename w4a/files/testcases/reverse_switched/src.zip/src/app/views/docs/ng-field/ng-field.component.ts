import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-field',
  templateUrl: './ng-field.component.html',
  styleUrls: ['./ng-field.component.css']
})
export class NgFieldComponent implements OnInit {

  contentToShow = 1;

  constructor() { }

  ngOnInit() {
  }

}

