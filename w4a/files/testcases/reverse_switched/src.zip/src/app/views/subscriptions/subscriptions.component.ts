import { Component, OnInit } from '@angular/core';
import { PayPalService } from '../../services/paypal.service';
import { Router } from '@angular/router';
import { Http, RequestOptions, Response, Headers, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { IUsageInterface } from '../../shared/IUsage.interface';
import { UsageService } from '../../services/usage.service';

@Component({
  selector: 'app-subscriptions',
  templateUrl: './subscriptions.component.html',
  styleUrls: [ './subscriptions.component.css' ]
})
export class SubscriptionsComponent implements OnInit {

  status: string;
  errorMessage: string;
  subscribed = true;
  expiring = false;
  expiryNotice = '';
  billingFreeTitle = 'The FreeFormJS 5 for FREE Daily Plan';


  constructor(private router: Router,
              private payPalService: PayPalService,
              private usageService: UsageService,
              private location: Location) {
  }

  ngOnInit() {
    this.usageService.getUsage()
      .subscribe(
        (usage: IUsageInterface) => {
          console.log(usage);
          this.subscribed = usage.subscribed;
          this.expiring = usage.expiring;
          this.doNotice();
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  doNotice() {
    if ( this.expiring && this.subscribed ) {
      this.expiryNotice = 'Your subscription has been cancelled by request ';
      this.expiryNotice += 'but you still have access to the member\'s area ';
      this.expiryNotice += 'for 30 days after the date of cancellation.';
    } else {
      this.expiryNotice = '';
    }
  }

}

