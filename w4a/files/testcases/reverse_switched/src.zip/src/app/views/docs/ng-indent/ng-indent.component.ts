import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-indent',
  templateUrl: './ng-indent.component.html',
  styleUrls: ['./ng-indent.component.css']
})
export class NgIndentComponent implements OnInit {

  contentToShow = 1;

  constructor() { }

  ngOnInit() {
  }

}

