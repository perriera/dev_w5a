import { Component, Input, OnInit } from '@angular/core';
import { ServerConstants, UploadMounts } from '../../../shared/Server.mounts';
import { FileItem } from 'ng2-file-upload';
import { DropZoneFileUploader } from '../../../symbols/drop-zone-box/DropZoneFileUploader';
import { IUploadStatus } from '../../../shared/IUploadStatus';
import * as FileSaver from 'file-saver';
import { DownloadService } from '../../../services/download.service';

@Component({
  selector: 'app-forward',
  templateUrl: './forward.component.html',
  styleUrls: [ './forward.component.css' ]
})
export class ForwardComponent implements OnInit {

  @Input() uploader: DropZoneFileUploader = new DropZoneFileUploader({
    url: ServerConstants.base + UploadMounts.upload
  });

  token = 'F-45382';

  constructor() {
  }

  ngOnInit(): void {
    this.uploader.setToken(this.token);
  }

}
