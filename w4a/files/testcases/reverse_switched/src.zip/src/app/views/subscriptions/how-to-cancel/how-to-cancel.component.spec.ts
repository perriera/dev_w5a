/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { HowToCancelComponent } from './how-to-cancel.component';

describe('HowToCancelComponent', () => {
  let component: HowToCancelComponent;
  let fixture: ComponentFixture<HowToCancelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToCancelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToCancelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

