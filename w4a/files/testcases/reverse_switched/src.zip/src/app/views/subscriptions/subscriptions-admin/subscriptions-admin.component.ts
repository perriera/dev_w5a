import { Component, OnInit } from '@angular/core';
import { PayPalService } from '../../../services/paypal.service';
import { Router } from '@angular/router';
import { Cursor } from '../../../shared/Cursor.container';
import { IBillingPlanDocument } from '../../../shared/IBillingPlan.interface';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-subscriptions-admin',
  templateUrl: './subscriptions-admin.component.html',
  styleUrls: [ './subscriptions-admin.component.css' ]
})
export class SubscriptionsAdminComponent implements OnInit {

  status: string;
  errorMessage: string;

  constructor(private router: Router,
              private payPalService: PayPalService) {
  }

  ngOnInit() {
  }

  onCreateAndActivate() {
    this.status = 'processing';
    this.payPalService.createAndActivate()
      .subscribe(
        () => {
          this.status = 'good';
          this.payPalService.billingPlansUpdated.next();
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  onResetBillingPlans() {
    this.status = 'processing';
    this.payPalService.resetBillingPlans()
      .subscribe(
        () => {
          this.status = 'good';
          this.payPalService.billingPlansUpdated.next();
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

}

