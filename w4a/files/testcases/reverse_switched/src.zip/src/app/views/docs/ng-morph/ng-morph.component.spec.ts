/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { NgMorphComponent } from './ng-morph.component';

describe('NgMorphComponent', () => {
  let component: NgMorphComponent;
  let fixture: ComponentFixture<NgMorphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgMorphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgMorphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

