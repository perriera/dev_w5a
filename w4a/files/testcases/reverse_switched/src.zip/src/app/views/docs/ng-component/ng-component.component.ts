import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-component',
  templateUrl: './ng-component.component.html',
  styleUrls: ['./ng-component.component.css']
})
export class NgComponentComponent implements OnInit {

  contentToShow = 1;

  constructor() { }

  ngOnInit() {
  }

}

