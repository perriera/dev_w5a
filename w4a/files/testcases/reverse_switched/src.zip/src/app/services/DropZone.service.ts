import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
/**
 * Created by perry on 2017-08-15.
 */

@Injectable()
export class DropZoneService {

  onClearButton = new Subject();
  setStatus = new Subject();
  downloadedOk =  new Subject();

}
