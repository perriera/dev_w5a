/**
 * Created by perry on 2017-07-03.
 */

import { Headers, Http, RequestOptions, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Session } from '../models/Session.model';
import { Router } from '@angular/router';
import { AuthMounts, ServerConstants } from '../shared/Server.mounts';
import { User } from '../models/User.model';
import { Registration } from '../models/Registratation.model';
import { IUserDocument } from '../shared/IUser.interface';

@Injectable()
export class AuthService {

  loginActivated = new Subject();
  session: Session;
  base = ServerConstants.base;

  signUpURL = this.base + AuthMounts.signUp;
  signInURL = this.base + AuthMounts.signIn;
  signOutURL = this.base + AuthMounts.signOut;
  meURL = this.base + AuthMounts.me;
  stuffURL = this.base + AuthMounts.stuff;
  testPostURL = this.base + AuthMounts.testPost;
  checkAuthenticationURL = this.base + AuthMounts.checkAuthentication;

  constructor(private router: Router,
              private http: Http) {
    console.log('ServerConstants.base = ' + ServerConstants.base);
    console.log('ServerConstants.client = ' + ServerConstants.client);
  }

  isAuthenticated(): boolean {
    const state = this.session != null && this.session.loggedIn && this.session.token != null;
    return state;
  }

  getToken() {
    // console.log('ServerConstants.base = ' + ServerConstants.base);
    // console.log('ServerConstants.client = ' + ServerConstants.client);
    return this.session.token;
  }

  getOptions() {
    const headers = new Headers({ 'Authorization': this.getToken() });
    const options = new RequestOptions({ headers: headers });
    return options;
  }

  stringify(key: string, session: Session) {
    const encrypted = JSON.stringify(session);
    localStorage.setItem(key, encrypted);
  }

  isSessionHidden(key: string) {
    return localStorage.getItem(key) != null;
  }

  unStringify(key: string) {
    const encrypted = localStorage.getItem(key);
    localStorage.removeItem(key);
    const session = JSON.parse(encrypted);
    return session;
  }

  storeToken() {
    this.stringify('hide', this.session);
  }

  restoreToken() {
    if (!this.session && this.isSessionHidden('hide')) {
      this.session = this.unStringify('hide');
      this.loginActivated.next(this.session);
    }
  }

  signupUser(params: Registration): Observable<IUserDocument> {
    return this.http.post(this.signUpURL, params)
      .map(
        (response: Response) => response.json() as IUserDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  signinUser(params: User): Observable<Session> {
    return this.http.post(this.signInURL, params)
      .map(
        (response: Response) => {
          this.session = response.json() as Session;
          this.session.loggedIn = true;
          this.loginActivated.next(this.session);
        }
      ).catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  signoutUser(): Observable<String> {
    this.session.loggedIn = false;
    this.loginActivated.next(this.session);
    return this.http.put(this.signOutURL, {}, this.getOptions())
      .map(
        (response: Response) => {
          this.session.token = response.json().token;
          return this.session.token;
        }
      ).catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  me() {
    return this.http.get(this.meURL, this.getOptions())
      .map(
        (response: Response) => response.json()
      ).catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  stuff() {
    return this.http.get(this.stuffURL)
      .map(
        (response: Response) => response.json()
      ).catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  testPost() {
    const options = this.getOptions();
    console.log(options);
    return this.http.post(this.testPostURL, {}, options)
      .map(
        (response: Response) => response.json()
      ).catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }


}
