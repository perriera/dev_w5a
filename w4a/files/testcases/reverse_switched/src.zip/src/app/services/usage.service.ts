import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Http, RequestOptions, Response, Headers, URLSearchParams } from '@angular/http';
import { ServerConstants, UsageMounts } from '../shared/Server.mounts';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class UsageService {

  usageState = new Subject();

  base = ServerConstants.base;
  _retrieve = this.base + UsageMounts.retrieve;

  errorMessage = '';
  exceeded = true;

  constructor(private router: Router,
              private authService: AuthService,
              private http: Http) {
  }

  exceededLimit() {
    if (!this.authService.isAuthenticated()) {
      return true;
    }
    this.getUsage()
      .subscribe(
        (usage) => {
          this.exceeded = usage.quota;
          this.usageState.next(usage);
        }, (error) => {
          this.errorMessage = 'Cannot connect to the server!';
          console.log(error);
        }
      );
    return this.exceeded;
  }

  retrieve(params: URLSearchParams) {

    const headers = new Headers({
      'Authorization': this.authService.getToken(),
      'Content-Type': 'application/json'
    });
    const options = new RequestOptions({
      headers: headers,
      search: params
    });

    return this.http.get(this._retrieve, options)
      .map(
        (response: Response) => response.json()
      )
      .catch(
        (error: any) => Observable.throw(error || 'Unknown server error')
      );

  }

  getUsage() {
    const params: URLSearchParams = new URLSearchParams();
    return this.retrieve(params);
  }

  bump() {
    const params: URLSearchParams = new URLSearchParams();
    params.set('bump', 'true');
    return this.retrieve(params);
  }

}
