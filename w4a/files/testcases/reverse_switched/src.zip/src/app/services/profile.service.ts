import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
/**
 * Created by perry on 2017-08-18.
 */

@Injectable()
export class ProfileService {

  toggleMenu = new Subject();

}
