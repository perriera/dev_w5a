/**
 * Created by perry on 2017-08-02.
 */

import { Headers, Http, RequestOptions, Response, ResponseContentType, URLSearchParams } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import { Router } from '@angular/router';
import { DownloadMounts, ServerConstants } from '../shared/Server.mounts';
import { IUploadStatus } from '../shared/IUploadStatus';
import { AuthService } from './auth.service';

@Injectable()
export class DownloadService {

  loginActivated = new Subject();
  base = ServerConstants.base;

  downloadTestURL = this.base + DownloadMounts.testZipFile;
  readyQueryURL = this.base + DownloadMounts.readyQuery;
  retrieveURL = this.base + DownloadMounts.retrieve;
  retrievePutURL = this.base + DownloadMounts.retrievePut;

  constructor(private router: Router,
              private authService: AuthService,
              private http: Http) {
  }

  getBlobOptions() {
    const headers = new Headers({
      'Authorization': this.authService.getToken(),
      'Content-Type': 'application/json',
      'Accept': 'application/zip'
    });
    const options = new RequestOptions({ headers: headers });
    options.responseType = ResponseContentType.Blob;
    return options;
  }

  getOptions() {
    const headers = new Headers({
      'Authorization': this.authService.getToken(),
      'Content-Type': 'application/json',
      'Accept': 'application/zip'
    });
    const options = new RequestOptions({ headers: headers });
    return options;
  }

  testDownload() {
    return this.http.get(this.downloadTestURL, this.getBlobOptions())
      .map(
        (response: Response) => {
          const fileBlob = response.blob();
          const blob = new Blob([ fileBlob ], {
            type: 'application/zip' // must match the Accept type
          });
          return blob;
        }
      )
      .catch(
        (error: any) => {
          console.log(error);
          return Observable.throw(error.json() || 'Unknown server error');
        }
      );
  }

  readyQuery(filename: string) {

    const params: URLSearchParams = new URLSearchParams();
    params.set('filename', filename);

    const headers = new Headers({
      'Authorization': this.authService.getToken(),
      'Content-Type': 'application/json',
      'Accept': 'application/zip'
    });
    const options = new RequestOptions({
      headers: headers,
      search: params
    });

    return this.http.get(this.readyQueryURL, options)
      .map(
        (response: Response) => {
          const results = response.json() as IUploadStatus;
          return results;
        }
      )
      .catch(
        (error: any) => {
          console.log(error);
          return Observable.throw(error.json() || 'Unknown server error');
        }
      );
  }

  retrieve(filename: string) {

    const params: URLSearchParams = new URLSearchParams();
    params.set('filename', filename);

    const headers = new Headers({
      'Authorization': this.authService.getToken(),
      'Content-Type': 'application/json'
    });
    const options = new RequestOptions({
      headers: headers,
      search: params
    });
    options.responseType = ResponseContentType.Blob;

    return this.http.get(this.retrieveURL, options)
      .map(
        (response: Response) => {
          const fileBlob = response.blob();
          const blob = new Blob([ fileBlob ], {
            type: 'application/zip' // must match the Accept type
          });
          return blob;
        }
      )
      .catch(
        (error: any) => {
          console.log(error);
          return Observable.throw(error.json() || 'Unknown server error');
        }
      );
  }

  retrievePut(filename: string) {
    return this.http.put(this.retrievePutURL, {
      filename: filename
    }, this.getBlobOptions())
      .map(
        (response: Response) => {
          const fileBlob = response.blob();
          const blob = new Blob([ fileBlob ], {
            type: 'application/zip' // must match the Accept type
          });
          return blob;
        }
      )
      .catch(
        (error: any) => {
          console.log(error);
          return Observable.throw(error.json() || 'Unknown server error');
        }
      );
  }

//   testDownload2() {
// // Parameters obj-
//     let params: URLSearchParams = new URLSearchParams();
//     params.set('appid', StaticSettings.API_KEY);
//     params.set('cnt', days.toString());
//
//     //Http request-
//     return this.http.get(StaticSettings.BASE_URL, {
//       search: params
//     }).subscribe(
//       (response) => this.onGetForecastResult(response.json()),
//       (error) => this.onGetForecastError(error.json()),
//       () => this.onGetForecastComplete()
//     );
//   }


}

