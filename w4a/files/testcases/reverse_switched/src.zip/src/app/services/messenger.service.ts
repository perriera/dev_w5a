import { ServerConstants } from '../shared/Server.mounts';
import { Subject } from 'rxjs/Subject';
import { Injectable } from '@angular/core';
/**
 * Created by perry on 2017-08-06.
 */

@Injectable()
export class MessengerService {

  fileSelected = new Subject();

}

