import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Injectable } from '@angular/core';

import { AuthService } from './auth.service';
import { UsageService } from './usage.service';

@Injectable()
export class UsageGuard implements CanActivate {

  constructor(private router: Router,
              private authService: AuthService,
              private usageService: UsageService) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (!this.authService.isAuthenticated()) {
      this.router.navigateByUrl('/');
      return false;
    }
    // if (this.usageService.exceededLimit()) {
    //   this.router.navigateByUrl('/');
    //   return false;
    // }
    return true;
  }

}
