/**
 * Created by perry on 2017-08-26.
 */

import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Http, RequestOptions, Response, Headers, URLSearchParams } from '@angular/http';
import { IBillingPlanDocument } from '../shared/IBillingPlan.interface';
import { Observable } from 'rxjs/Observable';
import { BillingAgreementMounts, BillingPlanMounts, ServerConstants } from '../shared/Server.mounts';
import { AuthService } from './auth.service';
import { Cursor } from '../shared/Cursor.container';
import { Subject } from 'rxjs/Subject';
import { IBillingAgreement } from '../shared/IBillingAgreement.interface';

@Injectable()
export class PayPalService {

  billingPlansUpdated = new Subject();

  base = ServerConstants.base;

  _createAndActivate = this.base + BillingPlanMounts.createAndActivate;
  _resetBillingPlans = this.base + BillingPlanMounts.resetBillingPlans;
  _queryPlans = this.base + BillingPlanMounts.queryPlans;

  _createAgreement = this.base + BillingAgreementMounts.createAgreement;
  _cancelAgreement = this.base + BillingAgreementMounts.cancelAgreement;

  constructor(private router: Router,
              private authService: AuthService,
              private http: Http) {
  }

  getOptions() {
    const headers = new Headers({
      'Authorization': this.authService.getToken(),
      'Content-Type': 'application/json'
    });
    const options = new RequestOptions({ headers: headers });
    return options;
  }

  createAndActivate(): Observable<IBillingPlanDocument> {
    return this.http.post(this._createAndActivate, {}, this.getOptions())
      .map(
        (response: Response) => response.json() as IBillingPlanDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  resetBillingPlans(): Observable<boolean> {
    return this.http.post(this._resetBillingPlans, {}, this.getOptions())
      .map(
        (response: Response) => response.json() as boolean
      )
      .catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  // let cursor = new Cursor<IArticle>(0, 20);

  queryPlans(cursor: Cursor<IBillingPlanDocument>): Observable<Cursor<IBillingPlanDocument>> {
    return this.http.put(this._queryPlans, cursor)
      .map(
        (response: Response) => response.json() as Cursor<IBillingPlanDocument>[]
      )
      .catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  createAgreement(bp: IBillingPlanDocument) {

    const params: URLSearchParams = new URLSearchParams();
    params.set('plan', bp.billingPlanId);

    const headers = new Headers({
      'Authorization': this.authService.getToken(),
      'Content-Type': 'application/json'
    });
    const options = new RequestOptions({
      headers: headers,
      search: params
    });

    return this.http.get(this._createAgreement, options)
      .map(
        (response: Response) => {
          this.authService.storeToken();
          return response.json();
        }
      )
      .catch(
        (error: any) => Observable.throw(error || 'Unknown server error')
      );
  }

  cancelAgreement() {

    return this.http.post(this._cancelAgreement, {}, this.getOptions())
      .map(
        (response: Response) => {
          this.authService.storeToken();
          return response.json();
        }
      )
      .catch(
        (error: any) => Observable.throw(error || 'Unknown server error')
      );
  }

}
