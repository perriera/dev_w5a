import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { ServerConstants } from '../shared/Server.mounts';
import { MyFileUploader } from '../symbols/drag-and-drop-box/MyFileUpLoader';
import { AuthService } from './auth.service';
/**
 * Created by perry on 2017-08-10.
 */

@Injectable()
export class UploadService {

  loginActivated = new Subject();
  base = ServerConstants.base;

  constructor(private authService: AuthService) {
  }

  uploadForwardEngineeringRequest(uploader: MyFileUploader) {
    uploader.uploadAll();
  }

  uploadReverseEngineeringRequest(uploader1: MyFileUploader, uploader2: MyFileUploader) {
    uploader1.uploadAll();
    uploader2.uploadAll();
  }


}
