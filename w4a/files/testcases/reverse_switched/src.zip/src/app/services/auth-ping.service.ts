import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import { Router } from '@angular/router';
import { AuthMounts, ServerConstants } from '../shared/Server.mounts';
import { AuthService } from './auth.service';
import { Session } from '../models/Session.model';

@Injectable()
export class AuthPingService {

  base = ServerConstants.base;

  pingURL = this.base + AuthMounts.ping;
  checkAuthenticationURL = this.base + AuthMounts.checkAuthentication;
  pingLaunched = false;

  constructor(private router: Router,
              private http: Http,
              private authService: AuthService) {
    this.authService.loginActivated
      .subscribe((session: Session) => {
        if (!session.loggedIn) {
          this.pingLaunched = false;
        }
      });
  }

  ping(): Observable<String> {
    return this.http.get(this.pingURL, this.authService.getOptions())
      .map(
        (response: Response) => response.json()
      ).catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  checkAuthentication() {
    return this.http.get(this.checkAuthenticationURL, this.authService.getOptions())
      .map(
        (response: Response) => response.json()
      ).catch(
        (error: any) => Observable.throw(error.json() || 'Unknown server error')
      );
  }

  monitorPing() {
    console.log('monitorPing()');
    if (!this.pingLaunched && this.authService.isAuthenticated()) {
      this.pingLaunched = true;
      setTimeout(() => {
        this.ping()
          .subscribe(
            (response: any) => {
              console.log(response);
              this.pingLaunched = false;
            }
          );
      }, 10000);
    }
  }

  monitorAccess() {
    console.log('monitorAccess()');
    setInterval(() => {
      if (this.authService.isAuthenticated()) {
        this.checkAuthentication()
          .subscribe(
            (response: any) => {
              console.log(response);
              if (!response.status) {
                console.log('Automatically logged off due to inactivity');
                this.authService.signoutUser();
                this.router.navigateByUrl('/');
              }
            }
          );
      }
    }, 10000);
  }
}
