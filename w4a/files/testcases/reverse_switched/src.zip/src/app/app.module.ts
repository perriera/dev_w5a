import { APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AreYouSureComponent } from './views/subscriptions/are-you-sure/are-you-sure.component';
import { AuthGuard } from './services/auth-guard.service';
import { AuthService } from './services/auth.service';
import { CancelCheckoutComponent } from './views/subscriptions/cancel-checkout/cancel-checkout.component';
import { CancellationComponent } from './views/subscriptions/cancellation/cancellation.component';
import { CopyrightInfoComponent } from './symbols/copyright-info/copyright-info.component';
import { DndDirective } from './directives/DndDirective.directive';
import { DocumentationComponent } from './views/docs/documentation/documentation.component';
import { DownloadService } from './services/download.service';
import { DragAndDropBoxComponent } from './symbols/drag-and-drop-box/drag-and-drop-box.component';
import { DragAndDropComponent } from './symbols/drag-and-drop/drag-and-drop.component';
import { DropZoneBoxComponent } from './symbols/drop-zone-box/drop-zone-box.component';
import { DropZoneControlComponent } from './symbols/drop-zone-control/drop-zone-control.component';
import { DropZoneService } from './services/DropZone.service';
import { FileUploadModule } from 'ng2-file-upload';
import { ForwardComponent } from './views/code/forward/forward.component';
import { HomeComponent } from './views/home/home.component';
import { HowToCancelComponent } from './views/subscriptions/how-to-cancel/how-to-cancel.component';
import { LoginComponent } from './views/users/login/login.component';
import { LoginMenuComponent } from './symbols/login-menu/login-menu.component';
import { LogoComponent } from './symbols/logo/logo.component';
import { MainMenuComponent } from './symbols/main-menu/main-menu.component';
import { MessengerService } from './services/messenger.service';
import { NgComponentComponent } from './views/docs/ng-component/ng-component.component';
import { NgFieldComponent } from './views/docs/ng-field/ng-field.component';
import { NgIdComponent } from './views/docs/ng-id/ng-id.component';
import { NgIndentComponent } from './views/docs/ng-indent/ng-indent.component';
import { NgMorphComponent } from './views/docs/ng-morph/ng-morph.component';
import { NgRouterComponent } from './views/docs/ng-router/ng-router.component';
import { PayPalBoxComponent } from './symbols/pay-pal-box/pay-pal-box.component';
import { PayPalService } from './services/paypal.service';
import { PaymentComponent } from './symbols/payment-button/payment.component';
import { ProfileMenuComponent } from './symbols/profile-menu/profile-menu.component';
import { ProfileService } from './services/profile.service';
import { RegisterComponent } from './views/users/register/register.component';
import { ReverseComponent } from './views/code/reverse/reverse.component';
import { SubscriptionPlansListingComponent } from './symbols/subscription-plans-listing/subscription-plans-listing.component';
import { SubscriptionsAdminComponent } from './views/subscriptions/subscriptions-admin/subscriptions-admin.component';
import { SubscriptionsComponent } from './views/subscriptions/subscriptions.component';
import { SubscriptionsSelectionMenuComponent } from './symbols/subscriptions-selection-menu/subscriptions-selection-menu.component';
import { ThankYouComponent } from './views/subscriptions/thank-you/thank-you.component';
import { UploadService } from './services/upload.service';
import { UsageGuard } from './services/usage-guard.service';
import { UsageService } from './services/usage.service';

@NgModule({
  declarations: [
    AppComponent,
    AreYouSureComponent,
    CancelCheckoutComponent,
    CancellationComponent,
    CopyrightInfoComponent,
    DndDirective,
    DocumentationComponent,
    DragAndDropBoxComponent,
    DragAndDropComponent,
    DropZoneBoxComponent,
    DropZoneControlComponent,
    ForwardComponent,
    HomeComponent,
    HowToCancelComponent,
    LoginComponent,
    LoginMenuComponent,
    LogoComponent,
    MainMenuComponent,
    NgComponentComponent,
    NgFieldComponent,
    NgIdComponent,
    NgIndentComponent,
    NgMorphComponent,
    NgRouterComponent,
    PayPalBoxComponent,
    PaymentComponent,
    ProfileMenuComponent,
    RegisterComponent,
    ReverseComponent,
    SubscriptionPlansListingComponent,
    SubscriptionsAdminComponent,
    SubscriptionsComponent,
    SubscriptionsSelectionMenuComponent,
    ThankYouComponent,
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    FileUploadModule,
    FormsModule,
    HttpModule,
    RouterModule,
  ],
  providers: [
    AuthGuard,
    AuthService,
    DownloadService,
    DropZoneService,
    MessengerService,
    PayPalService,
    ProfileService,
    UploadService,
    UsageGuard,
    UsageService,
    {'useValue':'/','provide':'APP_BASE_HREF'},
  ],
  bootstrap: [
    AppComponent,
  ],
})
export class AppModule { }

