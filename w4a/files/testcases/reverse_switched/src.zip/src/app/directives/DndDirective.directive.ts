import { Directive, HostListener, HostBinding } from '@angular/core';


@Directive({
  selector: '[appDnd]'
})
export class DndDirective {

  @HostBinding('style.background') public background = '#eee';

  constructor() {
  }

  @HostListener('dragover', [ '$event' ])
  public onDragOver(evt) {
    evt.preventDefault();
    evt.stopPropagation();
    this.background = '#999';
  }

  @HostListener('dragleave', [ '$event' ])
  public onDragLeave(evt) {
    evt.preventDefault();
    evt.stopPropagation();
    this.background = '#eee';
  }

  uploadFiles(url, files) {
    const formData = new FormData();

    for (let i = 0, file; file = files[ i ]; ++i) {
      formData.append(file.name, file);
    }

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.onload = function (e) {
      console.log(e);
    };

    xhr.send(formData);  // multipart/form-data
  }

//   document.querySelector('input[type="file"]').onchange = function(e) {
//   uploadFiles('/server', this.files);
// };
//
  @HostListener('drop', [ '$event' ])
  public onDrop(evt) {

    evt.preventDefault();
    evt.stopPropagation();

    this.background = '#eee';
    const files = evt.dataTransfer.files;

    if (files.length > 0) {
      console.log(files);
      for (let i = 0; i < files.length; i++) {
        const file = files[ i ];
        const reader = new FileReader();

        // attach event handlers here...
        reader.onload = function (e) {

          // document.querySelector('input[type="file"]').onchange = function (e) {
          //   this.uploadFiles('/server', this.files);
          // };
          console.log(reader.result);

        };

        reader.readAsText(file);

      }
    }

  }

}
