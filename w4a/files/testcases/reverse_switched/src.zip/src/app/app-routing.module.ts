import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UsageGuard } from './services/usage-guard.service';
import { AuthGuard } from './services/auth-guard.service';
import { CancelCheckoutComponent } from './views/subscriptions/cancel-checkout/cancel-checkout.component';
import { CancellationComponent } from './views/subscriptions/cancellation/cancellation.component';
import { NgFieldComponent } from './views/docs/ng-field/ng-field.component';
import { NgIdComponent } from './views/docs/ng-id/ng-id.component';
import { DocumentationComponent } from './views/docs/documentation/documentation.component';
import { HomeComponent } from './views/home/home.component';
import { HowToCancelComponent } from './views/subscriptions/how-to-cancel/how-to-cancel.component';
import { LoginComponent } from './views/users/login/login.component';
import { ForwardComponent } from './views/code/forward/forward.component';
import { ReverseComponent } from './views/code/reverse/reverse.component';
import { NgComponentComponent } from './views/docs/ng-component/ng-component.component';
import { SubscriptionsAdminComponent } from './views/subscriptions/subscriptions-admin/subscriptions-admin.component';
import { SubscriptionsComponent } from './views/subscriptions/subscriptions.component';
import { NgRouterComponent } from './views/docs/ng-router/ng-router.component';
import { AreYouSureComponent } from './views/subscriptions/are-you-sure/are-you-sure.component';
import { NgMorphComponent } from './views/docs/ng-morph/ng-morph.component';
import { ThankYouComponent } from './views/subscriptions/thank-you/thank-you.component';
import { NgIndentComponent } from './views/docs/ng-indent/ng-indent.component';
import { RegisterComponent } from './views/users/register/register.component';

const appRoutes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'code_forward', component: ForwardComponent, canActivate: [ UsageGuard ] },
  { path: 'code_reverse', component: ReverseComponent, canActivate: [ UsageGuard ] },
  { path: 'users_register', component: RegisterComponent },
  { path: 'users_login', component: LoginComponent },
  { path: 'subscriptions_cancellation', component: CancellationComponent, canActivate: [ AuthGuard ] },
  { path: 'subscriptions_thank_you', component: ThankYouComponent, canActivate: [ AuthGuard ] },
  { path: 'subscriptions_cancel_checkout', component: CancelCheckoutComponent, canActivate: [ AuthGuard ] },
  { path: 'subscriptions', component: SubscriptionsComponent, canActivate: [ AuthGuard ] },
  { path: 'subscriptions_subscriptions_admin', component: SubscriptionsAdminComponent, canActivate: [ AuthGuard ] },
  { path: 'subscriptions_how_to_cancel', component: HowToCancelComponent },
  { path: 'subscriptions_are_you_sure', component: AreYouSureComponent },
	{ path: 'docs_documentation', component: DocumentationComponent, canActivate: [ AuthGuard ] },
	{ path: 'docs_ng_component', component: NgComponentComponent  },
	{ path: 'docs_ng_morph', component: NgMorphComponent  },
	{ path: 'docs_ng_router', component: NgRouterComponent  },
	{ path: 'docs_ng_id', component: NgIdComponent  },
	{ path: 'docs_ng_field', component: NgFieldComponent  },
	{ path: 'docs_ng_indent', component: NgIndentComponent  },
  { path: '404', component: HomeComponent },
  { path: '**', redirectTo: '/404' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes),
  ],
  exports: [
    RouterModule,
  ],
})
export class AppRoutingModule { }

