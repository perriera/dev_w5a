/**
 * Created by perry on 2017-08-18.
 */

import { IUserDocument } from '../shared/IUser.interface';


export class User implements IUserDocument {

  _id: string;

  // public static stringify(key: string, user: User) {
  //   const encrypted = JSON.stringify(user);
  //   localStorage.setItem(key, encrypted);
  // }
  //
  // public static unStringify(key: string) {
  //   const encrypted = localStorage.getItem(key);
  //   const user = JSON.parse(encrypted);
  //   return user;
  // }

  constructor(public username: string,
              public email: string,
              public password: string) {
  }

}

