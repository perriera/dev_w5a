/**
 * Created by perry on 2017-08-18.
 */

import { User } from './User.model';
import { ISessionDocument } from '../shared/ISession.interface';


export class Session implements ISessionDocument {

  sid: string;
  expires: number;
  _id: string;

  // public static stringify(key: string, session: Session) {
  //   const encrypted = JSON.stringify(session);
  //   localStorage.setItem(key, encrypted);
  // }
  //
  // public static unStringify(key: string) {
  //   const encrypted = localStorage.getItem(key);
  //   const session = JSON.parse(encrypted);
  //   return session;
  // }

  constructor(public user: User,
              public token: string,
              public loggedIn: boolean) {
  }

}
