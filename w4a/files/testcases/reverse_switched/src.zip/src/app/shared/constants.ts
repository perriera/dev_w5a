import * as os from 'os';

const xyz_or_org = ( os.hostname().indexOf('.xyz') > 0 ? 'xyz' : 'org' );

export const constants = {
    server_port: 3001,
    client_port: 3300,
    actualhostingmachinename: 'www.freeformjs.' + xyz_or_org,
    hostname: 'localhost',
    key: '../ssl/local/localhost.key',
    cert: '../ssl/local/localhost.crt',
    ca: '../ssl/local/localhost.ca',
    live_key: '../ssl/gen/www_freeformjs_' + xyz_or_org + '.key',
    live_cert: '../ssl/live/www_freeformjs_' + xyz_or_org + '.crt',
    live_ca: '../ssl/live/www_freeformjs_' + xyz_or_org + '.ca-bundle',
    http_protocol: 'https://',
    base: '',
    client: '',
    server: '',
    shareDir: '../share',
    swapFile: '../share/swapfile.txt',
    live: false
};

constants.base = constants.http_protocol + constants.hostname;
constants.server = constants.base + ':' + constants.server_port;
constants.client = constants.base; //  + ':' + constants.client_port;

if (constants.actualhostingmachinename.includes(os.hostname())) {
    constants.hostname = constants.actualhostingmachinename;
    constants.key = constants.live_key;
    constants.cert = constants.live_cert;
    constants.ca = constants.live_ca;
    constants.base = constants.http_protocol + constants.hostname;
    constants.server = constants.base + ':' + constants.server_port;
    constants.client = constants.base; // + ':' + constants.client_port;
    constants.live = true;
}

console.log(constants);

