"use strict";
var fs = require('fs');
var Server_mounts_1 = require('./Server.mounts');
var ShareFiles = (function () {
    function ShareFiles() {
        this.swapFile = Server_mounts_1.ServerConstants.swapFile;
        if (!fs.existsSync(Server_mounts_1.ServerConstants.shareDir)) {
            fs.mkdirSync(Server_mounts_1.ServerConstants.shareDir);
        }
    }
    ;
    ShareFiles.prototype.output = function (data) {
        var txt = JSON.stringify(data);
        fs.writeFileSync(this.swapFile, txt);
    };
    ShareFiles.prototype.input = function () {
        var data = null;
        if (fs.existsSync(this.swapFile)) {
            var txt = fs.readFileSync(this.swapFile, 'utf8');
            data = JSON.parse(txt);
            fs.unlinkSync(this.swapFile);
        }
        return data;
    };
    return ShareFiles;
}());
exports.ShareFiles = ShareFiles;
