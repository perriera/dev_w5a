/**
 * Created by perry on 2017-07-24.
 */

export class Cursor<T> {

    public cache: T[];
    public size: number;

    public static pageUp(cursor) {
        cursor.pointer -= ( cursor.pointer > cursor.limit ? cursor.limit : cursor.pointer );
    }

    public static pageDown(cursor) {
        cursor.pointer += ( cursor.pointer < cursor.size - cursor.limit ? cursor.limit : 0 );
    }

    public static parameters(cursor) {
        return new Cursor(cursor.pointer, cursor.limit);
    }

    constructor(public pointer: number = 0,
                public limit: number = 5) {
    }

    top() {
        this.pointer = 0;
    }

    bottom() {
        this.pointer = this.size;
    }

}

