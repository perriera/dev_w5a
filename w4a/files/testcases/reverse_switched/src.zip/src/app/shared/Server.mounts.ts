/**
 * Created by perry on 2017-07-28.
 */

import * as os from 'os';
import { constants } from './constants';

export class ServerConstants {

    public static server_port = constants.server_port;
    public static client_port = constants.client_port;
    public static base = constants.server;
    public static server = constants.server;
    public static client = constants.client;
    public static live = constants.live;
    public static live_key = constants.live_key;

    public static live_cert = constants.live_cert;
    public static live_ca = constants.live_ca;
    public static shareDir = constants.shareDir;
    public static swapFile = constants.swapFile;


    public static key = constants.key;
    public static cert = constants.cert;
    public static ca = constants.ca;

    constructor() {
        console.log('os.type() = ' + os.type());
        console.log('os.hostname() = ' + os.hostname());
        console.log('ServerConstants.server_port = ' + ServerConstants.server_port);
        console.log('ServerConstants.base = ' + ServerConstants.base);
        console.log('ServerConstants.client_port = ' + ServerConstants.client_port);
        console.log('ServerConstants.client = ' + ServerConstants.client);
        console.log('UploadMounts.directory = ' + UploadMounts.directory);
        console.log('ServerConstants.key = ' + ServerConstants.key);
        console.log('ServerConstants.cert = ' + ServerConstants.cert);
        console.log('ServerConstants.ca = ' + ServerConstants.ca);
        console.log('ServerConstants.live = ' + ServerConstants.live);
        console.log(' BillingAgreementMounts.processAgreement = ' + BillingAgreementMounts.processAgreement);
    }

}

export class ServerMounts {

    public static root = '/';
    public static api_auth = '/api/auth';
    public static api_uploads = '/api/uploads';
    public static api_downloads = '/api/downloads';
    public static api_paypal = '/api/paypal';
    public static api_billingPlan = '/api/billingPlan';
    public static api_billingAgreement = '/api/billingAgreement';
    public static api_useage = '/api/usage';

}

export class UsageMounts extends ServerMounts {

    public static _retrieve = '/retrieve';

    public static retrieve = ServerMounts.api_useage + UsageMounts._retrieve;

}

export class WebhookMounts extends ServerMounts {

    public static _montor = '/monitor';

    public static montor = ServerMounts.api_useage + WebhookMounts._montor;

}

export class BillingAgreementMounts extends ServerMounts {

    public static _createAgreement = '/createagreement';
    public static _processAgreement = '/processagreement';
    public static _cancelRequest = '/cancelrequest';
    public static _cancelAgreement = '/cancelAgreement';
    public static _webHook = '/webhook';

    public static createAgreement = ServerMounts.api_billingAgreement + BillingAgreementMounts._createAgreement;
    public static processAgreement = ServerConstants.server + ServerMounts.api_billingAgreement + BillingAgreementMounts._processAgreement;
    public static cancelRequest = ServerConstants.server + ServerMounts.api_billingAgreement + BillingAgreementMounts._cancelRequest;
    public static thank_you = ServerConstants.client + '/subscriptions_thank_you';
    public static request_cancelled = ServerConstants.client + '/subscriptions_cancel_checkout';
    public static cancelAgreement = ServerMounts.api_billingAgreement + BillingAgreementMounts._cancelAgreement;
    public static webHook = ServerMounts.api_billingAgreement + BillingAgreementMounts._webHook;

}

export class BillingPlanMounts extends ServerMounts {

    public static _createAndActivate = '/createAndActivate';
    public static _queryPlans = '/queryPlans';
    public static _resetBillingPlans = '/resetBillingPlans';

    public static createAndActivate = ServerMounts.api_billingPlan + BillingPlanMounts._createAndActivate;
    public static queryPlans = ServerMounts.api_billingPlan + BillingPlanMounts._queryPlans;
    public static resetBillingPlans = ServerMounts.api_billingPlan + BillingPlanMounts._resetBillingPlans;

}

export class PayPalMounts extends ServerMounts {

    public static _authenticate = '/authenticate';
    public static _success = '/success';
    public static _fail = '/fail';
    public static _createSubscription = '/createSubscription';
    public static _getSubscription = '/getSubscription';
    public static _modifySubscription = '/modifySubscription';

    public static authenticate = ServerMounts.api_paypal + PayPalMounts._authenticate;
    public static success = ServerConstants.server + ServerMounts.api_paypal + PayPalMounts._success;
    public static fail = ServerConstants.server + ServerMounts.api_paypal + PayPalMounts._fail;
    public static createSubscription = ServerMounts.api_paypal + PayPalMounts._createSubscription;
    public static getSubscription = ServerMounts.api_paypal + PayPalMounts._getSubscription;
    public static modifySubscription = ServerMounts.api_paypal + PayPalMounts._modifySubscription;

}

export class AuthMounts extends ServerMounts {

    public static _signUp = '/signUp';
    public static _signIn = '/signIn';
    public static _me = '/me';
    public static _stuff = '/stuff';
    public static _signOut = '/signOut';
    public static _testPost = '/testPost';
    public static _ping = '/ping';
    public static _checkAuthentication = '/checkAuthentication';

    public static signUp = ServerMounts.api_auth + AuthMounts._signUp;
    public static signIn = ServerMounts.api_auth + AuthMounts._signIn;
    public static me = ServerMounts.api_auth + AuthMounts._me;
    public static stuff = ServerMounts.api_auth + AuthMounts._stuff;
    public static signOut = ServerMounts.api_auth + AuthMounts._signOut;
    public static testPost = ServerMounts.api_auth + AuthMounts._testPost;
    public static ping = ServerMounts.api_auth + AuthMounts._ping;
    public static checkAuthentication = ServerMounts.api_auth + AuthMounts._checkAuthentication;

}

export class UploadMounts extends ServerMounts {

    public static _upload = '/upload';
    public static _test = '/test';
    public static _ping = '/ping';
    public static _directory = '../mock-server/dev/uploads/';

    public static upload = ServerMounts.api_uploads + UploadMounts._upload;
    public static ping = ServerMounts.api_uploads + UploadMounts._ping;
    public static directory = UploadMounts._directory;

}

export class DownloadMounts extends ServerMounts {

    public static _download = '/download';
    public static _testTextFile = '/testtextfile';
    public static _testZipFile = '/testzipfile.zip';
    public static _ping = '/ping';
    public static _directory = '../mock-server/dev/downloads/';
    public static _readyQuery = '/readyQuery';
    public static _retrieve = '/retrieve';
    public static _retrievePut = '/retrievePut';

    public static download = ServerMounts.api_downloads + DownloadMounts._download;
    public static testTextFile = ServerMounts.api_downloads + DownloadMounts._testTextFile;
    public static testZipFile = ServerMounts.api_downloads + DownloadMounts._testZipFile;
    public static ping = ServerMounts.api_downloads + DownloadMounts._ping;
    public static directory = DownloadMounts._directory;
    public static readyQuery = ServerMounts.api_downloads + DownloadMounts._readyQuery;
    public static retrieve = ServerMounts.api_downloads + DownloadMounts._retrieve;
    public static retrievePut = ServerMounts.api_downloads + DownloadMounts._retrievePut;

}

