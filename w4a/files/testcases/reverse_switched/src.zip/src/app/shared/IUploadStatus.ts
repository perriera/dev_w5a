/**
 * Created by perry on 2017-08-14.
 */

export interface Document { _id: string; }

export interface IUploadStatus {
    exception: boolean,
    exceptionMsg: string,
    percentage: number,
    downloadsFileExist: boolean,
    uploadsFileExist: boolean,
    filename: string,
    statfile: string
}

export interface IUploadStatusDocument extends Document, IUploadStatus {
}

