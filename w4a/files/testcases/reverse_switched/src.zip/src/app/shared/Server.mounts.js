/**
 * Created by perry on 2017-07-28.
 */
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var os = require('os');
var constants_1 = require('./constants');
var ServerConstants = (function () {
    function ServerConstants() {
        console.log('os.type() = ' + os.type());
        console.log('os.hostname() = ' + os.hostname());
        console.log('ServerConstants.server_port = ' + ServerConstants.server_port);
        console.log('ServerConstants.base = ' + ServerConstants.base);
        console.log('ServerConstants.client_port = ' + ServerConstants.client_port);
        console.log('ServerConstants.client = ' + ServerConstants.client);
        console.log('UploadMounts.directory = ' + UploadMounts.directory);
        console.log('ServerConstants.key = ' + ServerConstants.key);
        console.log('ServerConstants.cert = ' + ServerConstants.cert);
        console.log('ServerConstants.ca = ' + ServerConstants.ca);
        console.log('ServerConstants.live = ' + ServerConstants.live);
        console.log(' BillingAgreementMounts.processAgreement = ' + BillingAgreementMounts.processAgreement);
    }
    ServerConstants.server_port = constants_1.constants.server_port;
    ServerConstants.client_port = constants_1.constants.client_port;
    ServerConstants.base = constants_1.constants.server;
    ServerConstants.server = constants_1.constants.server;
    ServerConstants.client = constants_1.constants.client;
    ServerConstants.live = constants_1.constants.live;
    ServerConstants.live_key = constants_1.constants.live_key;
    ServerConstants.live_cert = constants_1.constants.live_cert;
    ServerConstants.live_ca = constants_1.constants.live_ca;
    ServerConstants.shareDir = constants_1.constants.shareDir;
    ServerConstants.swapFile = constants_1.constants.swapFile;
    ServerConstants.key = constants_1.constants.key;
    ServerConstants.cert = constants_1.constants.cert;
    ServerConstants.ca = constants_1.constants.ca;
    return ServerConstants;
}());
exports.ServerConstants = ServerConstants;
var ServerMounts = (function () {
    function ServerMounts() {
    }
    ServerMounts.root = '/';
    ServerMounts.api_auth = '/api/auth';
    ServerMounts.api_uploads = '/api/uploads';
    ServerMounts.api_downloads = '/api/downloads';
    ServerMounts.api_paypal = '/api/paypal';
    ServerMounts.api_billingPlan = '/api/billingPlan';
    ServerMounts.api_billingAgreement = '/api/billingAgreement';
    ServerMounts.api_useage = '/api/usage';
    return ServerMounts;
}());
exports.ServerMounts = ServerMounts;
var UsageMounts = (function (_super) {
    __extends(UsageMounts, _super);
    function UsageMounts() {
        _super.apply(this, arguments);
    }
    UsageMounts._retrieve = '/retrieve';
    UsageMounts.retrieve = ServerMounts.api_useage + UsageMounts._retrieve;
    return UsageMounts;
}(ServerMounts));
exports.UsageMounts = UsageMounts;
var WebhookMounts = (function (_super) {
    __extends(WebhookMounts, _super);
    function WebhookMounts() {
        _super.apply(this, arguments);
    }
    WebhookMounts._montor = '/monitor';
    WebhookMounts.montor = ServerMounts.api_useage + WebhookMounts._montor;
    return WebhookMounts;
}(ServerMounts));
exports.WebhookMounts = WebhookMounts;
var BillingAgreementMounts = (function (_super) {
    __extends(BillingAgreementMounts, _super);
    function BillingAgreementMounts() {
        _super.apply(this, arguments);
    }
    BillingAgreementMounts._createAgreement = '/createagreement';
    BillingAgreementMounts._processAgreement = '/processagreement';
    BillingAgreementMounts._cancelRequest = '/cancelrequest';
    BillingAgreementMounts._cancelAgreement = '/cancelAgreement';
    BillingAgreementMounts._webHook = '/webhook';
    BillingAgreementMounts.createAgreement = ServerMounts.api_billingAgreement + BillingAgreementMounts._createAgreement;
    BillingAgreementMounts.processAgreement = ServerConstants.server + ServerMounts.api_billingAgreement + BillingAgreementMounts._processAgreement;
    BillingAgreementMounts.cancelRequest = ServerConstants.server + ServerMounts.api_billingAgreement + BillingAgreementMounts._cancelRequest;
    BillingAgreementMounts.thank_you = ServerConstants.client + '/subscriptions_thank_you';
    BillingAgreementMounts.request_cancelled = ServerConstants.client + '/subscriptions_cancel_checkout';
    BillingAgreementMounts.cancelAgreement = ServerMounts.api_billingAgreement + BillingAgreementMounts._cancelAgreement;
    BillingAgreementMounts.webHook = ServerMounts.api_billingAgreement + BillingAgreementMounts._webHook;
    return BillingAgreementMounts;
}(ServerMounts));
exports.BillingAgreementMounts = BillingAgreementMounts;
var BillingPlanMounts = (function (_super) {
    __extends(BillingPlanMounts, _super);
    function BillingPlanMounts() {
        _super.apply(this, arguments);
    }
    BillingPlanMounts._createAndActivate = '/createAndActivate';
    BillingPlanMounts._queryPlans = '/queryPlans';
    BillingPlanMounts._resetBillingPlans = '/resetBillingPlans';
    BillingPlanMounts.createAndActivate = ServerMounts.api_billingPlan + BillingPlanMounts._createAndActivate;
    BillingPlanMounts.queryPlans = ServerMounts.api_billingPlan + BillingPlanMounts._queryPlans;
    BillingPlanMounts.resetBillingPlans = ServerMounts.api_billingPlan + BillingPlanMounts._resetBillingPlans;
    return BillingPlanMounts;
}(ServerMounts));
exports.BillingPlanMounts = BillingPlanMounts;
var PayPalMounts = (function (_super) {
    __extends(PayPalMounts, _super);
    function PayPalMounts() {
        _super.apply(this, arguments);
    }
    PayPalMounts._authenticate = '/authenticate';
    PayPalMounts._success = '/success';
    PayPalMounts._fail = '/fail';
    PayPalMounts._createSubscription = '/createSubscription';
    PayPalMounts._getSubscription = '/getSubscription';
    PayPalMounts._modifySubscription = '/modifySubscription';
    PayPalMounts.authenticate = ServerMounts.api_paypal + PayPalMounts._authenticate;
    PayPalMounts.success = ServerConstants.server + ServerMounts.api_paypal + PayPalMounts._success;
    PayPalMounts.fail = ServerConstants.server + ServerMounts.api_paypal + PayPalMounts._fail;
    PayPalMounts.createSubscription = ServerMounts.api_paypal + PayPalMounts._createSubscription;
    PayPalMounts.getSubscription = ServerMounts.api_paypal + PayPalMounts._getSubscription;
    PayPalMounts.modifySubscription = ServerMounts.api_paypal + PayPalMounts._modifySubscription;
    return PayPalMounts;
}(ServerMounts));
exports.PayPalMounts = PayPalMounts;
var AuthMounts = (function (_super) {
    __extends(AuthMounts, _super);
    function AuthMounts() {
        _super.apply(this, arguments);
    }
    AuthMounts._signUp = '/signUp';
    AuthMounts._signIn = '/signIn';
    AuthMounts._me = '/me';
    AuthMounts._stuff = '/stuff';
    AuthMounts._signOut = '/signOut';
    AuthMounts._testPost = '/testPost';
    AuthMounts._ping = '/ping';
    AuthMounts._checkAuthentication = '/checkAuthentication';
    AuthMounts.signUp = ServerMounts.api_auth + AuthMounts._signUp;
    AuthMounts.signIn = ServerMounts.api_auth + AuthMounts._signIn;
    AuthMounts.me = ServerMounts.api_auth + AuthMounts._me;
    AuthMounts.stuff = ServerMounts.api_auth + AuthMounts._stuff;
    AuthMounts.signOut = ServerMounts.api_auth + AuthMounts._signOut;
    AuthMounts.testPost = ServerMounts.api_auth + AuthMounts._testPost;
    AuthMounts.ping = ServerMounts.api_auth + AuthMounts._ping;
    AuthMounts.checkAuthentication = ServerMounts.api_auth + AuthMounts._checkAuthentication;
    return AuthMounts;
}(ServerMounts));
exports.AuthMounts = AuthMounts;
var UploadMounts = (function (_super) {
    __extends(UploadMounts, _super);
    function UploadMounts() {
        _super.apply(this, arguments);
    }
    UploadMounts._upload = '/upload';
    UploadMounts._test = '/test';
    UploadMounts._ping = '/ping';
    UploadMounts._directory = '../mock-server/dev/uploads/';
    UploadMounts.upload = ServerMounts.api_uploads + UploadMounts._upload;
    UploadMounts.ping = ServerMounts.api_uploads + UploadMounts._ping;
    UploadMounts.directory = UploadMounts._directory;
    return UploadMounts;
}(ServerMounts));
exports.UploadMounts = UploadMounts;
var DownloadMounts = (function (_super) {
    __extends(DownloadMounts, _super);
    function DownloadMounts() {
        _super.apply(this, arguments);
    }
    DownloadMounts._download = '/download';
    DownloadMounts._testTextFile = '/testtextfile';
    DownloadMounts._testZipFile = '/testzipfile.zip';
    DownloadMounts._ping = '/ping';
    DownloadMounts._directory = '../mock-server/dev/downloads/';
    DownloadMounts._readyQuery = '/readyQuery';
    DownloadMounts._retrieve = '/retrieve';
    DownloadMounts._retrievePut = '/retrievePut';
    DownloadMounts.download = ServerMounts.api_downloads + DownloadMounts._download;
    DownloadMounts.testTextFile = ServerMounts.api_downloads + DownloadMounts._testTextFile;
    DownloadMounts.testZipFile = ServerMounts.api_downloads + DownloadMounts._testZipFile;
    DownloadMounts.ping = ServerMounts.api_downloads + DownloadMounts._ping;
    DownloadMounts.directory = DownloadMounts._directory;
    DownloadMounts.readyQuery = ServerMounts.api_downloads + DownloadMounts._readyQuery;
    DownloadMounts.retrieve = ServerMounts.api_downloads + DownloadMounts._retrieve;
    DownloadMounts.retrievePut = ServerMounts.api_downloads + DownloadMounts._retrievePut;
    return DownloadMounts;
}(ServerMounts));
exports.DownloadMounts = DownloadMounts;
