/**
 * Created by perry on 2017-07-31.
 */

export interface ISubscription {

    from: string;
    to: string;
    subject: string;
    text: string;
    html: string;

}

