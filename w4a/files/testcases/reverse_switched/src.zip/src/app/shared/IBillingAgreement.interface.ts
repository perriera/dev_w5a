/**
 * Created by perry on 2017-07-31.
 */

export interface Document { _id: string; }
import { IUserDocument } from './IUser.interface';

export interface IBillingAgreement {
    billingAgreementId: string;
    billingPlanId: string;
    userid: string;
    title: string;
    token: string;
    contract: string;
    limit: number;
    executed: boolean;
    dateSigned: number;
    cancelled: boolean;
    expiring: boolean;
    expiryDate: number;
    expired: boolean;
}

export interface IBillingAgreementDocument extends Document, IBillingAgreement {
}

