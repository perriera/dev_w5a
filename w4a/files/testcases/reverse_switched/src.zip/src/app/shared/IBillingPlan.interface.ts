/**
 * Created by perry on 2017-07-31.
 */

export interface Document { _id: string; }

export interface IBillingPlan {
    billingPlanId: string;
    title: string;
    limit: number;
}

export interface IBillingPlanDocument extends Document, IBillingPlan {
}

