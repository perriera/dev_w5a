import * as fs from 'fs';
import { ServerConstants } from './Server.mounts';

export class ShareFiles {

    swapFile = ServerConstants.swapFile;

    constructor() {
        if (!fs.existsSync(ServerConstants.shareDir)) {
            fs.mkdirSync(ServerConstants.shareDir);
        }
    };

    output(data) {
        const txt = JSON.stringify(data);
        fs.writeFileSync(this.swapFile, txt);
    }

    input() {
        let data = null;
        if (fs.existsSync(this.swapFile)) {
            let txt = fs.readFileSync(this.swapFile, 'utf8');
            data = JSON.parse(txt);
            fs.unlinkSync(this.swapFile);
        }
        return data;
    }

}

