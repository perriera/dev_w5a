"use strict";
var os = require('os');
var xyz_or_org = (os.hostname().indexOf('.xyz') > 0 ? 'xyz' : 'org');
exports.constants = {
    server_port: 3001,
    client_port: 3300,
    actualhostingmachinename: 'www.freeformjs.' + xyz_or_org,
    hostname: 'localhost',
    key: '../ssl/local/localhost.key',
    cert: '../ssl/local/localhost.crt',
    ca: '../ssl/local/localhost.ca',
    live_key: '../ssl/gen/www_freeformjs_' + xyz_or_org + '.key',
    live_cert: '../ssl/live/www_freeformjs_' + xyz_or_org + '.crt',
    live_ca: '../ssl/live/www_freeformjs_' + xyz_or_org + '.ca-bundle',
    http_protocol: 'https://',
    base: '',
    client: '',
    server: '',
    shareDir: '../share',
    swapFile: '../share/swapfile.txt',
    live: false
};
exports.constants.base = exports.constants.http_protocol + exports.constants.hostname;
exports.constants.server = exports.constants.base + ':' + exports.constants.server_port;
exports.constants.client = exports.constants.base; //  + ':' + constants.client_port;
if (exports.constants.actualhostingmachinename.includes(os.hostname())) {
    exports.constants.hostname = exports.constants.actualhostingmachinename;
    exports.constants.key = exports.constants.live_key;
    exports.constants.cert = exports.constants.live_cert;
    exports.constants.ca = exports.constants.live_ca;
    exports.constants.base = exports.constants.http_protocol + exports.constants.hostname;
    exports.constants.server = exports.constants.base + ':' + exports.constants.server_port;
    exports.constants.client = exports.constants.base; // + ':' + constants.client_port;
    exports.constants.live = true;
}
console.log(exports.constants);
