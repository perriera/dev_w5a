/**
 * Created by perry on 2017-07-25.
 */

export interface Document { _id: string; }
import { IBillingAgreement } from './IBillingAgreement.interface';

export interface IUsageInterface {
    userid: string;
    title: string;
    expires: number;
    usages: number;
    limit: number;
    quota: boolean;
    subscribed: boolean;
    expiring: boolean;
}

export interface IUsageDocument extends Document, IUsageInterface {
}

