/**
 * Created by perry on 2017-08-15.
 */

export class Token {

    public static getTokenFromFilename(filename: string) {
        const parts1 = filename.split('-');
        if (parts1.length > 1) {
            const parts2 = parts1[ 1 ].split('_');
            if (parts2.length > 1) {
                return parts2[ 0 ];
            }
        }
        throw new Error('NoTokenFoundInFilenameException( "' + filename + '" )');
    }

    public static getDownloadFilename(oldname: string) {
        if (!oldname.includes('.webflow.')) {
            const msg = 'WebflowNotIncludedInNameOfUploadFile( "' + oldname + '" )';
            // throw new Error(msg);
            console.warn(msg);
        }
        const newname = oldname.replace('.webflow.', '.freeformjs.');
        return newname;
    }

}

