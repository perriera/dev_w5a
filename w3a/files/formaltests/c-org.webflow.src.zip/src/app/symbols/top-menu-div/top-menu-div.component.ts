import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../controls/auth.service';
import { Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { Session } from '../../models/Session.model';

@Component({
  selector: 'app-top-menu-div',
  templateUrl: './top-menu-div.component.html',
  styleUrls: [ './top-menu-div.component.css' ]
})
export class TopMenuDivComponent implements OnInit {

  loginActivated = new Subject();

  loggedIn = false;
  session: Session;
  showProfile = false;

  constructor(private router: Router,
              private authService: AuthService) {
  }

  ngOnInit() {
    this.authService.loginActivated
      .subscribe((state: Session) => {
        this.session = state;
        this.loggedIn = this.session.loggedIn;
        this.showProfile = this.session.loggedIn;
      });
  }

  onSignout() {
    this.showProfile = false;
    this.authService.signoutUser()
      .subscribe(
        () => {
          console.log('signed out');
          this.router.navigateByUrl('/');
        }, (error) => {
          console.log(error.message);
        }
      );
  }

}
