import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebardiv',
  templateUrl: './sidebardiv.component.html',
  styleUrls: ['./sidebardiv.component.css']
})
export class SidebardivComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
