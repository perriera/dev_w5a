/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { SidebardivComponent } from './sidebardiv.component';

describe('SidebardivComponent', () => {
  let component: SidebardivComponent;
  let fixture: ComponentFixture<SidebardivComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SidebardivComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SidebardivComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
