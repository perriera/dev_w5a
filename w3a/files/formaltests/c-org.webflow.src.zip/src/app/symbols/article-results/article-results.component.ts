import { Component, OnInit, Input, Injectable } from '@angular/core';
import { IArticle, IArticleDocument } from '../../shared/IArticle.interface';
import { ArticleService } from '../../controls/article.service';
import { Cursor } from '../../shared/Cursor.container';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-article-results',
  templateUrl: './article-results.component.html',
  styleUrls: [ './article-results.component.css' ]
})
export class ArticleResultsComponent implements OnInit {

  errorMessage = '';
  articles: IArticleDocument[];
  cursor: Cursor<IArticle>;
  @Input() publicListing = true;
  @Input() showEditMenu = false;

  ng_parameter1 = '';

  constructor(private articleService: ArticleService,
              private route: ActivatedRoute,
              private router: Router) {
    this.cursor = new Cursor<IArticle>(0, 5);
  }

  ngOnInit() {
    this.updateListing();
  }

  onPageDown() {
    Cursor.pageDown(this.cursor);
    this.updateListing();
  }

  onPageUp() {
    Cursor.pageUp(this.cursor);
    this.updateListing();
  }

  onView(i: number) {
    const id = this.articles[i]._id;
    this.router.navigate([ '/articles_review_an_article', id, ]);
  }

  onEdit(i: number) {
    const id = this.articles[i]._id;
    this.router.navigate([ '/articles_review_an_article', id, 'edit']);
  }

  onDelete(i: number) {
    const id = this.articles[i]._id;
    this.router.navigate([ '/articles_review_an_article', id, 'delete']);
  }

  onPublish(i: number) {
    const id = this.articles[i]._id;
    this.router.navigate([ '/articles_review_an_article', id, 'publish']);
  }

  onUnPublish(i: number) {
    const id = this.articles[i]._id;
    this.router.navigate([ '/articles_review_an_article', id, 'unpublish']);
  }

  updateListing() {
    if (this.publicListing) {
      this.updatePublicListing();
    } else {
      this.updatePrivateListing();
    }
  }

  updatePublicListing() {
    this.articleService.getPublicArticlesWithCursor(this.cursor)
      .subscribe(
        (response: Cursor<IArticle>) => {
          this.cursor = response as Cursor<IArticle>;
          this.articles = this.cursor.cache as IArticleDocument[];
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  updatePrivateListing() {
    this.articleService.getPrivateArticlesWithCursor(this.cursor)
      .subscribe(
        (response: Cursor<IArticle>) => {
          this.cursor = response as Cursor<IArticle>;
          this.articles = this.cursor.cache as IArticleDocument[];
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

}
