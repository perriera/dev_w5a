/**
 * Created by perry on 2017-07-28.
 */

import { IUserDocument } from '../shared/IUser.interface';

export class Registration implements IUserDocument {

  _id: string;

  constructor(public username: string,
              public email: string,
              public password: string,
              public verify: string) {
  }

}


