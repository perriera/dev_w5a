import { IUserDocument } from '../shared/IUser.interface';


export class User implements IUserDocument {

  _id: string;

  constructor(public username: string,
              public email: string,
              public password: string) {
  }

}

