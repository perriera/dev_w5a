/**
 * Created by perry on 2017-07-28.
 */

export class Error {

  constructor(public message: string) {
  }

}

