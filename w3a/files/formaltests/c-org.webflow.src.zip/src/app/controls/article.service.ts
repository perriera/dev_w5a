/**
 * Created by perry on 2017-07-03.
 */

import { Http, RequestOptions, Headers } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { AuthService } from './auth.service';
import { IArticle, IArticleDocument } from '../shared/IArticle.interface';
import { Cursor } from '../shared/Cursor.container';
import { Article } from '../models/Article.model';
import { ArticleMounts, ArticlesMounts, ServerConstants } from '../shared/Server.mounts';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class ArticleService {

  articleSubmitted = new Subject();

  base = ServerConstants.base;

  publicUrl = this.base + ArticlesMounts.getPublic;
  publicArticleURL = this.base + ArticleMounts.getPublic;
  privateArticleURL = this.base + ArticleMounts.getPrivate;
  publicArticlesURL = this.base + ArticlesMounts.getPublicCursor;
  privateArticlesURL = this.base + ArticlesMounts.getPrivateCursor;
  resetDatabaseURL = this.base + ArticlesMounts.resetDatabase;
  createTestDataURL = this.base + ArticlesMounts.createTestData;
  createArticleURL = this.base + ArticleMounts.create;
  updateArticleTextURL = this.base + ArticleMounts.updateText;
  updateArticleURL = this.base + ArticleMounts.update;
  deleteArticleURL = this.base + ArticleMounts.delete;
  publishArticleURL = this.base + ArticleMounts.publishText;
  unPublishArticleURL = this.base + ArticleMounts.unPublishText;
  errorMessage = 'Unknown server error';

  private options = new RequestOptions({
    headers: new Headers({ 'Content-Type': 'application/json' })
  });

  constructor(private http: Http,
              private authService: AuthService) {
  }

  addArticle(params: IArticleDocument) {
    return this.http
      .post(this.createArticleURL, params, this.authService.getOptions())
      .map(
        response => response.json() as IArticleDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  updateArticleText(params: IArticleDocument) {
    return this.http
      .put(this.updateArticleTextURL, params, this.authService.getOptions())
      .map(
        response => response.json() as IArticleDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  updateArticle(params: Article): Observable<IArticleDocument> {
    return this.http
      .put(this.updateArticleURL, params, this.authService.getOptions())
      .map(
        response => response.json() as IArticleDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  deleteArticle(params: Article): Observable<IArticleDocument> {
    return this.http
      .put(this.deleteArticleURL, params, this.authService.getOptions())
      .map(
        response => response.json() as IArticleDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  publishArticle(params: Article): Observable<IArticleDocument> {
    return this.http
      .put(this.publishArticleURL, params, this.authService.getOptions())
      .map(
        response => response.json() as IArticleDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  unPublishArticle(params: Article): Observable<IArticleDocument> {
    return this.http
      .put(this.unPublishArticleURL, params, this.authService.getOptions())
      .map(
        response => response.json() as IArticleDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  getPublicArticles(): Observable<IArticleDocument> {
    return this.http
      .get(this.publicUrl)
      .map(
        response => response.json() as IArticleDocument
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  getPublicArticle(_id: string): Observable<Article> {
    return this.http
      .put(this.publicArticleURL, { _id: _id })
      .map(
        response => response.json() as Article
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  getPrivateArticle(_id: string): Observable<Article> {
    return this.http
      .put(this.privateArticleURL, { _id: _id }, this.authService.getOptions())
      .map(
        response => response.json() as Article
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  getPublicArticlesWithCursor(cursor: Cursor<IArticle>): Observable<Cursor<IArticle>> {
    const request = Cursor.parameters(cursor);
    return this.http
      .put(this.publicArticlesURL, request)
      .map(
        response => response.json() as Cursor<IArticle>
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  getPrivateArticlesWithCursor(cursor: Cursor<IArticle>): Observable<Cursor<IArticle>> {
    const request = Cursor.parameters(cursor);
    return this.http
      .put(this.privateArticlesURL, request, this.authService.getOptions())
      .map(
        response => response.json() as Cursor<IArticle>
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  createTestData(): Observable<Error> {
    return this.http
      .post(this.createTestDataURL, {}, this.authService.getOptions())
      .map(
        response => response.json() as { message: string }
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  resetArticles(): Observable<Error> {
    return this.http
      .delete(this.resetDatabaseURL, this.authService.getOptions())
      .map(
        response => response.json() as { message: string }
      )
      .catch(
        (error: any) => Observable.throw(error.json() || this.errorMessage)
      );
  }

  // removeArticle(id: string): Observable<IArticleDocument[]> {
  //   return this.http
  //     .delete(`${this.deleteArticleUrl}/${id}`, this.authService.getOptions())
  //     .map(
  //       (res: Response) => res.json() as IArticleDocument
  //     )
  //     .catch(
  //       (error: any) => Observable.throw(error.json().error || this.errorMessage)
  //     );
  // }

}
