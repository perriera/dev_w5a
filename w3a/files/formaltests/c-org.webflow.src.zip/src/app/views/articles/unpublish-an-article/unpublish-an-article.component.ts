import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ArticleService } from '../../../controls/article.service';
import { Article } from '../../../models/Article.model';

@Component({
  selector: 'app-unpublish-an-article',
  templateUrl: './unpublish-an-article.component.html',
  styleUrls: ['./unpublish-an-article.component.css']
})
export class UnpublishAnArticleComponent implements OnInit {

  article = new Article();
  showUnPublishButton = true;
  showConfirmButton = false;
  errorMessage = '';

  constructor(private articleService: ArticleService,
              private route: ActivatedRoute,
              private router: Router) {
  }

  ngOnInit() {

    this.errorMessage = '';

    this.route.params
      .subscribe(
        (params: Params) => {
          this.articleService.getPrivateArticle(params[ 'id' ])
            .subscribe(
              (article: Article) => this.article = article as Article,
              (error) => this.errorMessage = error.message
            );
        }
      );

  }

  onUnPublishButton() {
    this.showUnPublishButton = false;
    this.showConfirmButton = true;
  }

  onConfirmButton() {
    this.articleService.unPublishArticle(this.article)
      .subscribe(
        (article: Article) => {
          this.article = article as Article;
          this.router.navigate([ '/users_profile' ]);
        },
        (error) => this.errorMessage = error.message
      );
  }

  onCancelButton() {
    this.router.navigate([ '/users_profile' ]);
  }

}
