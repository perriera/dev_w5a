import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-an-article',
  templateUrl: './remove-an-article.component.html',
  styleUrls: ['./remove-an-article.component.css']
})
export class RemoveAnArticleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
