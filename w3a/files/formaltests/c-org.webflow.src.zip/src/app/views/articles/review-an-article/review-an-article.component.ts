import { Component, OnInit } from '@angular/core';
import { Article } from '../../../models/Article.model';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ArticleService } from '../../../controls/article.service';

@Component({
  selector: 'app-review-an-article',
  templateUrl: './review-an-article.component.html',
  styleUrls: [ './review-an-article.component.css' ]
})
export class ReviewAnArticleComponent implements OnInit {

  ngOnInit() {
  }

}
