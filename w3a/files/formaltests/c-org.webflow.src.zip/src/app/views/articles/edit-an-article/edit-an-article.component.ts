import { Component, OnInit } from '@angular/core';
import { Article } from '../../../models/Article.model';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ArticleService } from '../../../controls/article.service';

@Component({
  selector: 'app-edit-an-article',
  templateUrl: './edit-an-article.component.html',
  styleUrls: [ './edit-an-article.component.css' ]
})
export class EditAnArticleComponent implements OnInit {

  article = new Article();
  errorMessage = '';

  constructor(private articleService: ArticleService,
              private route: ActivatedRoute,
              private router: Router) {
  }

  ngOnInit() {

    this.errorMessage = '';

    this.articleService.articleSubmitted
      .subscribe(
        (article: Article) => {
          this.article = article;
          this.router.navigate([ '/articles_review_an_article', article._id ]);
        }
      );

  }


}
