import { Component, OnInit } from '@angular/core';
import { ArticleService } from '../../../controls/article.service';
import { AuthService } from '../../../controls/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-utilities',
  templateUrl: './utilities.component.html',
  styleUrls: ['./utilities.component.css']
})
export class UtilitiesComponent implements OnInit {

  diagnostic = '';
  errorMessage = '';

  constructor(private router: Router,
              private authService: AuthService,
              private articleService: ArticleService) {
  }

  ngOnInit() {
  }

  onGenerateDatabase() {
    this.errorMessage = '';
    this.articleService.createTestData()
      .subscribe(
        (response) => {
          this.diagnostic = response.message;
          console.log(response);
        }, (error) => {
          this.errorMessage = error.message;
          console.log(error);
        }
      );
  }

  onResetDatabase() {
    this.errorMessage = '';
    this.articleService.resetArticles()
      .subscribe(
        (response) => {
          this.diagnostic =  response.message;
          console.log(response);
        }, (error) => {
          this.errorMessage = 'Cannot connect to the server!';
          console.log(error);
        }
      );
  }


}
