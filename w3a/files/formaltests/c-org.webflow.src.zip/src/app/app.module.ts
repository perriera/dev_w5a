import { APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { ArticleDetailComponent } from './symbols/article-detail/article-detail.component';
import { ArticleEditComponent } from './symbols/article-edit/article-edit.component';
import { ArticleResultsComponent } from './symbols/article-results/article-results.component';
import { ArticleService } from './controls/article.service';
import { AuthGuard } from './controls/auth-guard.service';
import { AuthPingService } from './controls/auth-ping.service';
import { AuthService } from './controls/auth.service';
import { DeleteAnArticleComponent } from './views/articles/delete-an-article/delete-an-article.component';
import { EditAnArticleComponent } from './views/articles/edit-an-article/edit-an-article.component';
import { HomeComponent } from './views/home/home.component';
import { LoginComponent } from './views/users/login/login.component';
import { PostAnArticleComponent } from './views/articles/post-an-article/post-an-article.component';
import { ProfileComponent } from './views/users/profile/profile.component';
import { PublishAnArticleComponent } from './views/articles/publish-an-article/publish-an-article.component';
import { QuillEditorModule } from 'ng2-quill-editor';
import { RegisterComponent } from './views/users/register/register.component';
import { ReviewAnArticleComponent } from './views/articles/review-an-article/review-an-article.component';
import { SidebardivComponent } from './symbols/sidebardiv/sidebardiv.component';
import { SubmitAnArticleComponent } from './views/articles/submit-an-article/submit-an-article.component';
import { TopMenuDivComponent } from './symbols/top-menu-div/top-menu-div.component';
import { UnpublishAnArticleComponent } from './views/articles/unpublish-an-article/unpublish-an-article.component';
import { UtilitiesComponent } from './views/users/utilities/utilities.component';

@NgModule({
  declarations: [
    AppComponent,
    ArticleDetailComponent,
    ArticleEditComponent,
    ArticleResultsComponent,
    DeleteAnArticleComponent,
    EditAnArticleComponent,
    HomeComponent,
    LoginComponent,
    PostAnArticleComponent,
    ProfileComponent,
    PublishAnArticleComponent,
    RegisterComponent,
    ReviewAnArticleComponent,
    SidebardivComponent,
    SubmitAnArticleComponent,
    TopMenuDivComponent,
    UnpublishAnArticleComponent,
    UtilitiesComponent,
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    FormsModule,
    HttpModule,
    QuillEditorModule,
    RouterModule,
  ],
  providers: [
    ArticleService,
    AuthGuard,
    AuthPingService,
    AuthService,
    {'useValue':'/','provide':'APP_BASE_HREF'},
  ],
  bootstrap: [
    AppComponent,
  ],
})
export class AppModule { }

